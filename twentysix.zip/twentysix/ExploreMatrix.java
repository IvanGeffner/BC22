package twentysix;

public class ExploreMatrix {

    int[][] expl;

    ExploreMatrix(int dim){

    }

}
