package twentysix;


import battlecode.common.Direction;
import battlecode.common.MapLocation;
import battlecode.common.RobotController;

public class BFSArchon extends BFS {

    BFSArchon(RobotController rc){
        super(rc);
    }

    static MapLocation l16;
    static double v16;
    static Direction d16;
    static double p16;

    static MapLocation l17;
    static double v17;
    static Direction d17;
    static double p17;

    static MapLocation l18;
    static double v18;
    static Direction d18;
    static double p18;

    static MapLocation l19;
    static double v19;
    static Direction d19;
    static double p19;

    static MapLocation l20;
    static double v20;
    static Direction d20;
    static double p20;

    static MapLocation l21;
    static double v21;
    static Direction d21;
    static double p21;

    static MapLocation l22;
    static double v22;
    static Direction d22;
    static double p22;

    static MapLocation l28;
    static double v28;
    static Direction d28;
    static double p28;

    static MapLocation l29;
    static double v29;
    static Direction d29;
    static double p29;

    static MapLocation l30;
    static double v30;
    static Direction d30;
    static double p30;

    static MapLocation l31;
    static double v31;
    static Direction d31;
    static double p31;

    static MapLocation l32;
    static double v32;
    static Direction d32;
    static double p32;

    static MapLocation l33;
    static double v33;
    static Direction d33;
    static double p33;

    static MapLocation l34;
    static double v34;
    static Direction d34;
    static double p34;

    static MapLocation l35;
    static double v35;
    static Direction d35;
    static double p35;

    static MapLocation l36;
    static double v36;
    static Direction d36;
    static double p36;

    static MapLocation l40;
    static double v40;
    static Direction d40;
    static double p40;

    static MapLocation l41;
    static double v41;
    static Direction d41;
    static double p41;

    static MapLocation l42;
    static double v42;
    static Direction d42;
    static double p42;

    static MapLocation l43;
    static double v43;
    static Direction d43;
    static double p43;

    static MapLocation l44;
    static double v44;
    static Direction d44;
    static double p44;

    static MapLocation l45;
    static double v45;
    static Direction d45;
    static double p45;

    static MapLocation l46;
    static double v46;
    static Direction d46;
    static double p46;

    static MapLocation l47;
    static double v47;
    static Direction d47;
    static double p47;

    static MapLocation l48;
    static double v48;
    static Direction d48;
    static double p48;

    static MapLocation l49;
    static double v49;
    static Direction d49;
    static double p49;

    static MapLocation l50;
    static double v50;
    static Direction d50;
    static double p50;

    static MapLocation l53;
    static double v53;
    static Direction d53;
    static double p53;

    static MapLocation l54;
    static double v54;
    static Direction d54;
    static double p54;

    static MapLocation l55;
    static double v55;
    static Direction d55;
    static double p55;

    static MapLocation l56;
    static double v56;
    static Direction d56;
    static double p56;

    static MapLocation l57;
    static double v57;
    static Direction d57;
    static double p57;

    static MapLocation l58;
    static double v58;
    static Direction d58;
    static double p58;

    static MapLocation l59;
    static double v59;
    static Direction d59;
    static double p59;

    static MapLocation l60;
    static double v60;
    static Direction d60;
    static double p60;

    static MapLocation l61;
    static double v61;
    static Direction d61;
    static double p61;

    static MapLocation l62;
    static double v62;
    static Direction d62;
    static double p62;

    static MapLocation l63;
    static double v63;
    static Direction d63;
    static double p63;

    static MapLocation l66;
    static double v66;
    static Direction d66;
    static double p66;

    static MapLocation l67;
    static double v67;
    static Direction d67;
    static double p67;

    static MapLocation l68;
    static double v68;
    static Direction d68;
    static double p68;

    static MapLocation l69;
    static double v69;
    static Direction d69;
    static double p69;

    static MapLocation l70;
    static double v70;
    static Direction d70;
    static double p70;

    static MapLocation l71;
    static double v71;
    static Direction d71;
    static double p71;

    static MapLocation l72;
    static double v72;
    static Direction d72;
    static double p72;

    static MapLocation l73;
    static double v73;
    static Direction d73;
    static double p73;

    static MapLocation l74;
    static double v74;
    static Direction d74;
    static double p74;

    static MapLocation l75;
    static double v75;
    static Direction d75;
    static double p75;

    static MapLocation l76;
    static double v76;
    static Direction d76;
    static double p76;

    static MapLocation l79;
    static double v79;
    static Direction d79;
    static double p79;

    static MapLocation l80;
    static double v80;
    static Direction d80;
    static double p80;

    static MapLocation l81;
    static double v81;
    static Direction d81;
    static double p81;

    static MapLocation l82;
    static double v82;
    static Direction d82;
    static double p82;

    static MapLocation l83;
    static double v83;
    static Direction d83;
    static double p83;

    static MapLocation l84;
    static double v84;
    static Direction d84;
    static double p84;

    static MapLocation l85;
    static double v85;
    static Direction d85;
    static double p85;

    static MapLocation l86;
    static double v86;
    static Direction d86;
    static double p86;

    static MapLocation l87;
    static double v87;
    static Direction d87;
    static double p87;

    static MapLocation l88;
    static double v88;
    static Direction d88;
    static double p88;

    static MapLocation l89;
    static double v89;
    static Direction d89;
    static double p89;

    static MapLocation l92;
    static double v92;
    static Direction d92;
    static double p92;

    static MapLocation l93;
    static double v93;
    static Direction d93;
    static double p93;

    static MapLocation l94;
    static double v94;
    static Direction d94;
    static double p94;

    static MapLocation l95;
    static double v95;
    static Direction d95;
    static double p95;

    static MapLocation l96;
    static double v96;
    static Direction d96;
    static double p96;

    static MapLocation l97;
    static double v97;
    static Direction d97;
    static double p97;

    static MapLocation l98;
    static double v98;
    static Direction d98;
    static double p98;

    static MapLocation l99;
    static double v99;
    static Direction d99;
    static double p99;

    static MapLocation l100;
    static double v100;
    static Direction d100;
    static double p100;

    static MapLocation l101;
    static double v101;
    static Direction d101;
    static double p101;

    static MapLocation l102;
    static double v102;
    static Direction d102;
    static double p102;

    static MapLocation l105;
    static double v105;
    static Direction d105;
    static double p105;

    static MapLocation l106;
    static double v106;
    static Direction d106;
    static double p106;

    static MapLocation l107;
    static double v107;
    static Direction d107;
    static double p107;

    static MapLocation l108;
    static double v108;
    static Direction d108;
    static double p108;

    static MapLocation l109;
    static double v109;
    static Direction d109;
    static double p109;

    static MapLocation l110;
    static double v110;
    static Direction d110;
    static double p110;

    static MapLocation l111;
    static double v111;
    static Direction d111;
    static double p111;

    static MapLocation l112;
    static double v112;
    static Direction d112;
    static double p112;

    static MapLocation l113;
    static double v113;
    static Direction d113;
    static double p113;

    static MapLocation l114;
    static double v114;
    static Direction d114;
    static double p114;

    static MapLocation l115;
    static double v115;
    static Direction d115;
    static double p115;

    static MapLocation l118;
    static double v118;
    static Direction d118;
    static double p118;

    static MapLocation l119;
    static double v119;
    static Direction d119;
    static double p119;

    static MapLocation l120;
    static double v120;
    static Direction d120;
    static double p120;

    static MapLocation l121;
    static double v121;
    static Direction d121;
    static double p121;

    static MapLocation l122;
    static double v122;
    static Direction d122;
    static double p122;

    static MapLocation l123;
    static double v123;
    static Direction d123;
    static double p123;

    static MapLocation l124;
    static double v124;
    static Direction d124;
    static double p124;

    static MapLocation l125;
    static double v125;
    static Direction d125;
    static double p125;

    static MapLocation l126;
    static double v126;
    static Direction d126;
    static double p126;

    static MapLocation l127;
    static double v127;
    static Direction d127;
    static double p127;

    static MapLocation l128;
    static double v128;
    static Direction d128;
    static double p128;

    static MapLocation l132;
    static double v132;
    static Direction d132;
    static double p132;

    static MapLocation l133;
    static double v133;
    static Direction d133;
    static double p133;

    static MapLocation l134;
    static double v134;
    static Direction d134;
    static double p134;

    static MapLocation l135;
    static double v135;
    static Direction d135;
    static double p135;

    static MapLocation l136;
    static double v136;
    static Direction d136;
    static double p136;

    static MapLocation l137;
    static double v137;
    static Direction d137;
    static double p137;

    static MapLocation l138;
    static double v138;
    static Direction d138;
    static double p138;

    static MapLocation l139;
    static double v139;
    static Direction d139;
    static double p139;

    static MapLocation l140;
    static double v140;
    static Direction d140;
    static double p140;

    static MapLocation l146;
    static double v146;
    static Direction d146;
    static double p146;

    static MapLocation l147;
    static double v147;
    static Direction d147;
    static double p147;

    static MapLocation l148;
    static double v148;
    static Direction d148;
    static double p148;

    static MapLocation l149;
    static double v149;
    static Direction d149;
    static double p149;

    static MapLocation l150;
    static double v150;
    static Direction d150;
    static double p150;

    static MapLocation l151;
    static double v151;
    static Direction d151;
    static double p151;

    static MapLocation l152;
    static double v152;
    static Direction d152;
    static double p152;


    Direction getBestDir(MapLocation target){
        l84 = rc.getLocation();
        v84 = 0;
        l85 = l84.add(Direction.NORTH);
        v85 = 1000000;
        d85 = null;
        l72 = l85.add(Direction.WEST);
        v72 = 1000000;
        d72 = null;
        l71 = l72.add(Direction.SOUTH);
        v71 = 1000000;
        d71 = null;
        l70 = l71.add(Direction.SOUTH);
        v70 = 1000000;
        d70 = null;
        l83 = l70.add(Direction.EAST);
        v83 = 1000000;
        d83 = null;
        l96 = l83.add(Direction.EAST);
        v96 = 1000000;
        d96 = null;
        l97 = l96.add(Direction.NORTH);
        v97 = 1000000;
        d97 = null;
        l98 = l97.add(Direction.NORTH);
        v98 = 1000000;
        d98 = null;
        l99 = l98.add(Direction.NORTH);
        v99 = 1000000;
        d99 = null;
        l86 = l99.add(Direction.WEST);
        v86 = 1000000;
        d86 = null;
        l73 = l86.add(Direction.WEST);
        v73 = 1000000;
        d73 = null;
        l60 = l73.add(Direction.WEST);
        v60 = 1000000;
        d60 = null;
        l59 = l60.add(Direction.SOUTH);
        v59 = 1000000;
        d59 = null;
        l58 = l59.add(Direction.SOUTH);
        v58 = 1000000;
        d58 = null;
        l57 = l58.add(Direction.SOUTH);
        v57 = 1000000;
        d57 = null;
        l56 = l57.add(Direction.SOUTH);
        v56 = 1000000;
        d56 = null;
        l69 = l56.add(Direction.EAST);
        v69 = 1000000;
        d69 = null;
        l82 = l69.add(Direction.EAST);
        v82 = 1000000;
        d82 = null;
        l95 = l82.add(Direction.EAST);
        v95 = 1000000;
        d95 = null;
        l108 = l95.add(Direction.EAST);
        v108 = 1000000;
        d108 = null;
        l109 = l108.add(Direction.NORTH);
        v109 = 1000000;
        d109 = null;
        l110 = l109.add(Direction.NORTH);
        v110 = 1000000;
        d110 = null;
        l111 = l110.add(Direction.NORTH);
        v111 = 1000000;
        d111 = null;
        l112 = l111.add(Direction.NORTH);
        v112 = 1000000;
        d112 = null;
        l113 = l112.add(Direction.NORTH);
        v113 = 1000000;
        d113 = null;
        l100 = l113.add(Direction.WEST);
        v100 = 1000000;
        d100 = null;
        l87 = l100.add(Direction.WEST);
        v87 = 1000000;
        d87 = null;
        l74 = l87.add(Direction.WEST);
        v74 = 1000000;
        d74 = null;
        l61 = l74.add(Direction.WEST);
        v61 = 1000000;
        d61 = null;
        l48 = l61.add(Direction.WEST);
        v48 = 1000000;
        d48 = null;
        l47 = l48.add(Direction.SOUTH);
        v47 = 1000000;
        d47 = null;
        l46 = l47.add(Direction.SOUTH);
        v46 = 1000000;
        d46 = null;
        l45 = l46.add(Direction.SOUTH);
        v45 = 1000000;
        d45 = null;
        l44 = l45.add(Direction.SOUTH);
        v44 = 1000000;
        d44 = null;
        l43 = l44.add(Direction.SOUTH);
        v43 = 1000000;
        d43 = null;
        l42 = l43.add(Direction.SOUTH);
        v42 = 1000000;
        d42 = null;
        l55 = l42.add(Direction.EAST);
        v55 = 1000000;
        d55 = null;
        l68 = l55.add(Direction.EAST);
        v68 = 1000000;
        d68 = null;
        l81 = l68.add(Direction.EAST);
        v81 = 1000000;
        d81 = null;
        l94 = l81.add(Direction.EAST);
        v94 = 1000000;
        d94 = null;
        l107 = l94.add(Direction.EAST);
        v107 = 1000000;
        d107 = null;
        l120 = l107.add(Direction.EAST);
        v120 = 1000000;
        d120 = null;
        l121 = l120.add(Direction.NORTH);
        v121 = 1000000;
        d121 = null;
        l122 = l121.add(Direction.NORTH);
        v122 = 1000000;
        d122 = null;
        l123 = l122.add(Direction.NORTH);
        v123 = 1000000;
        d123 = null;
        l124 = l123.add(Direction.NORTH);
        v124 = 1000000;
        d124 = null;
        l125 = l124.add(Direction.NORTH);
        v125 = 1000000;
        d125 = null;
        l126 = l125.add(Direction.NORTH);
        v126 = 1000000;
        d126 = null;
        l114 = l126.add(Direction.NORTHWEST);
        v114 = 1000000;
        d114 = null;
        l101 = l114.add(Direction.WEST);
        v101 = 1000000;
        d101 = null;
        l88 = l101.add(Direction.WEST);
        v88 = 1000000;
        d88 = null;
        l75 = l88.add(Direction.WEST);
        v75 = 1000000;
        d75 = null;
        l62 = l75.add(Direction.WEST);
        v62 = 1000000;
        d62 = null;
        l49 = l62.add(Direction.WEST);
        v49 = 1000000;
        d49 = null;
        l35 = l49.add(Direction.SOUTHWEST);
        v35 = 1000000;
        d35 = null;
        l34 = l35.add(Direction.SOUTH);
        v34 = 1000000;
        d34 = null;
        l33 = l34.add(Direction.SOUTH);
        v33 = 1000000;
        d33 = null;
        l32 = l33.add(Direction.SOUTH);
        v32 = 1000000;
        d32 = null;
        l31 = l32.add(Direction.SOUTH);
        v31 = 1000000;
        d31 = null;
        l30 = l31.add(Direction.SOUTH);
        v30 = 1000000;
        d30 = null;
        l29 = l30.add(Direction.SOUTH);
        v29 = 1000000;
        d29 = null;
        l41 = l29.add(Direction.SOUTHEAST);
        v41 = 1000000;
        d41 = null;
        l54 = l41.add(Direction.EAST);
        v54 = 1000000;
        d54 = null;
        l67 = l54.add(Direction.EAST);
        v67 = 1000000;
        d67 = null;
        l80 = l67.add(Direction.EAST);
        v80 = 1000000;
        d80 = null;
        l93 = l80.add(Direction.EAST);
        v93 = 1000000;
        d93 = null;
        l106 = l93.add(Direction.EAST);
        v106 = 1000000;
        d106 = null;
        l119 = l106.add(Direction.EAST);
        v119 = 1000000;
        d119 = null;
        l133 = l119.add(Direction.NORTHEAST);
        v133 = 1000000;
        d133 = null;
        l134 = l133.add(Direction.NORTH);
        v134 = 1000000;
        d134 = null;
        l135 = l134.add(Direction.NORTH);
        v135 = 1000000;
        d135 = null;
        l136 = l135.add(Direction.NORTH);
        v136 = 1000000;
        d136 = null;
        l137 = l136.add(Direction.NORTH);
        v137 = 1000000;
        d137 = null;
        l138 = l137.add(Direction.NORTH);
        v138 = 1000000;
        d138 = null;
        l139 = l138.add(Direction.NORTH);
        v139 = 1000000;
        d139 = null;
        l127 = l139.add(Direction.NORTHWEST);
        v127 = 1000000;
        d127 = null;
        l115 = l127.add(Direction.NORTHWEST);
        v115 = 1000000;
        d115 = null;
        l102 = l115.add(Direction.WEST);
        v102 = 1000000;
        d102 = null;
        l89 = l102.add(Direction.WEST);
        v89 = 1000000;
        d89 = null;
        l76 = l89.add(Direction.WEST);
        v76 = 1000000;
        d76 = null;
        l63 = l76.add(Direction.WEST);
        v63 = 1000000;
        d63 = null;
        l50 = l63.add(Direction.WEST);
        v50 = 1000000;
        d50 = null;
        l36 = l50.add(Direction.SOUTHWEST);
        v36 = 1000000;
        d36 = null;
        l22 = l36.add(Direction.SOUTHWEST);
        v22 = 1000000;
        d22 = null;
        l21 = l22.add(Direction.SOUTH);
        v21 = 1000000;
        d21 = null;
        l20 = l21.add(Direction.SOUTH);
        v20 = 1000000;
        d20 = null;
        l19 = l20.add(Direction.SOUTH);
        v19 = 1000000;
        d19 = null;
        l18 = l19.add(Direction.SOUTH);
        v18 = 1000000;
        d18 = null;
        l17 = l18.add(Direction.SOUTH);
        v17 = 1000000;
        d17 = null;
        l16 = l17.add(Direction.SOUTH);
        v16 = 1000000;
        d16 = null;
        l28 = l16.add(Direction.SOUTHEAST);
        v28 = 1000000;
        d28 = null;
        l40 = l28.add(Direction.SOUTHEAST);
        v40 = 1000000;
        d40 = null;
        l53 = l40.add(Direction.EAST);
        v53 = 1000000;
        d53 = null;
        l66 = l53.add(Direction.EAST);
        v66 = 1000000;
        d66 = null;
        l79 = l66.add(Direction.EAST);
        v79 = 1000000;
        d79 = null;
        l92 = l79.add(Direction.EAST);
        v92 = 1000000;
        d92 = null;
        l105 = l92.add(Direction.EAST);
        v105 = 1000000;
        d105 = null;
        l118 = l105.add(Direction.EAST);
        v118 = 1000000;
        d118 = null;
        l132 = l118.add(Direction.NORTHEAST);
        v132 = 1000000;
        d132 = null;
        l146 = l132.add(Direction.NORTHEAST);
        v146 = 1000000;
        d146 = null;
        l147 = l146.add(Direction.NORTH);
        v147 = 1000000;
        d147 = null;
        l148 = l147.add(Direction.NORTH);
        v148 = 1000000;
        d148 = null;
        l149 = l148.add(Direction.NORTH);
        v149 = 1000000;
        d149 = null;
        l150 = l149.add(Direction.NORTH);
        v150 = 1000000;
        d150 = null;
        l151 = l150.add(Direction.NORTH);
        v151 = 1000000;
        d151 = null;
        l152 = l151.add(Direction.NORTH);
        v152 = 1000000;
        d152 = null;
        l140 = l152.add(Direction.NORTHWEST);
        v140 = 1000000;
        d140 = null;
        l128 = l140.add(Direction.NORTHWEST);
        v128 = 1000000;
        d128 = null;
        try {
            if (rc.onTheMap(l71)) {
                if (!rc.isLocationOccupied(l71)) {
                    p71 = 10 + rc.senseRubble(l71);
                    v71 = v84 + p71;
                    d71 = Direction.WEST;
                }
            }
            if (rc.onTheMap(l83)) {
                if (!rc.isLocationOccupied(l83)) {
                    p83 = 10 + rc.senseRubble(l83);
                    if (v84 > v71) {
                        v83 = v71 + p83;
                        d83 = d71;
                    } else {
                        v83 = v84 + p83;
                        d83 = Direction.SOUTH;
                    }
                }
            }
            if (rc.onTheMap(l85)) {
                if (!rc.isLocationOccupied(l85)) {
                    p85 = 10 + rc.senseRubble(l85);
                    if (v84 > v71) {
                        v85 = v71 + p85;
                        d85 = d71;
                    } else {
                        v85 = v84 + p85;
                        d85 = Direction.NORTH;
                    }
                }
            }
            if (rc.onTheMap(l97)) {
                if (!rc.isLocationOccupied(l97)) {
                    p97 = 10 + rc.senseRubble(l97);
                    if (v84 > v85) {
                        if (v85 > v83) {
                            v97 = v83 + p97;
                            d97 = d83;
                        } else {
                            v97 = v85 + p97;
                            d97 = d85;
                        }
                    } else {
                        if (v84 > v83) {
                            v97 = v83 + p97;
                            d97 = d83;
                        } else {
                            v97 = v84 + p97;
                            d97 = Direction.EAST;
                        }
                    }
                }
            }
            if (rc.onTheMap(l70)) {
                if (!rc.isLocationOccupied(l70)) {
                    p70 = 10 + rc.senseRubble(l70);
                    if (v84 > v71) {
                        if (v71 > v83) {
                            v70 = v83 + p70;
                            d70 = d83;
                        } else {
                            v70 = v71 + p70;
                            d70 = d71;
                        }
                    } else {
                        if (v84 > v83) {
                            v70 = v83 + p70;
                            d70 = d83;
                        } else {
                            v70 = v84 + p70;
                            d70 = Direction.SOUTHWEST;
                        }
                    }
                }
            }
            if (rc.onTheMap(l72)) {
                if (!rc.isLocationOccupied(l72)) {
                    p72 = 10 + rc.senseRubble(l72);
                    if (v84 > v71) {
                        if (v71 > v85) {
                            v72 = v85 + p72;
                            d72 = d85;
                        } else {
                            v72 = v71 + p72;
                            d72 = d71;
                        }
                    } else {
                        if (v84 > v85) {
                            v72 = v85 + p72;
                            d72 = d85;
                        } else {
                            v72 = v84 + p72;
                            d72 = Direction.NORTHWEST;
                        }
                    }
                }
            }
            if (rc.onTheMap(l96)) {
                if (!rc.isLocationOccupied(l96)) {
                    p96 = 10 + rc.senseRubble(l96);
                    if (v84 > v97) {
                        if (v97 > v83) {
                            v96 = v83 + p96;
                            d96 = d83;
                        } else {
                            v96 = v97 + p96;
                            d96 = d97;
                        }
                    } else {
                        if (v84 > v83) {
                            v96 = v83 + p96;
                            d96 = d83;
                        } else {
                            v96 = v84 + p96;
                            d96 = Direction.SOUTHEAST;
                        }
                    }
                }
            }
            if (rc.onTheMap(l98)) {
                if (!rc.isLocationOccupied(l98)) {
                    p98 = 10 + rc.senseRubble(l98);
                    if (v84 > v85) {
                        if (v85 > v97) {
                            v98 = v97 + p98;
                            d98 = d97;
                        } else {
                            v98 = v85 + p98;
                            d98 = d85;
                        }
                    } else {
                        if (v84 > v97) {
                            v98 = v97 + p98;
                            d98 = d97;
                        } else {
                            v98 = v84 + p98;
                            d98 = Direction.NORTHEAST;
                        }
                    }
                }
            }
            if (rc.onTheMap(l58)) {
                p58 = 10 + rc.senseRubble(l58);
                if (v71 > v70) {
                    if (v70 > v72) {
                        v58 = v72 + p58;
                        d58 = d72;
                    } else {
                        v58 = v70 + p58;
                        d58 = d70;
                    }
                } else {
                    if (v71 > v72) {
                        v58 = v72 + p58;
                        d58 = d72;
                    } else {
                        v58 = v71 + p58;
                        d58 = d71;
                    }
                }
            }
            if (rc.onTheMap(l82)) {
                p82 = 10 + rc.senseRubble(l82);
                if (v83 > v70) {
                    if (v70 > v96) {
                        v82 = v96 + p82;
                        d82 = d96;
                    } else {
                        v82 = v70 + p82;
                        d82 = d70;
                    }
                } else {
                    if (v83 > v96) {
                        v82 = v96 + p82;
                        d82 = d96;
                    } else {
                        v82 = v83 + p82;
                        d82 = d83;
                    }
                }
            }
            if (rc.onTheMap(l86)) {
                p86 = 10 + rc.senseRubble(l86);
                if (v85 > v72) {
                    if (v72 > v98) {
                        v86 = v98 + p86;
                        d86 = d98;
                    } else {
                        v86 = v72 + p86;
                        d86 = d72;
                    }
                } else {
                    if (v85 > v98) {
                        v86 = v98 + p86;
                        d86 = d98;
                    } else {
                        v86 = v85 + p86;
                        d86 = d85;
                    }
                }
            }
            if (rc.onTheMap(l110)) {
                p110 = 10 + rc.senseRubble(l110);
                if (v97 > v98) {
                    if (v98 > v96) {
                        v110 = v96 + p110;
                        d110 = d96;
                    } else {
                        v110 = v98 + p110;
                        d110 = d98;
                    }
                } else {
                    if (v97 > v96) {
                        v110 = v96 + p110;
                        d110 = d96;
                    } else {
                        v110 = v97 + p110;
                        d110 = d97;
                    }
                }
            }
            if (rc.onTheMap(l57)) {
                p57 = 10 + rc.senseRubble(l57);
                if (v71 > v70) {
                    if (v70 > v58) {
                        v57 = v58 + p57;
                        d57 = d58;
                    } else {
                        v57 = v70 + p57;
                        d57 = d70;
                    }
                } else {
                    if (v71 > v58) {
                        v57 = v58 + p57;
                        d57 = d58;
                    } else {
                        v57 = v71 + p57;
                        d57 = d71;
                    }
                }
            }
            if (rc.onTheMap(l59)) {
                p59 = 10 + rc.senseRubble(l59);
                if (v71 > v72) {
                    if (v72 > v58) {
                        v59 = v58 + p59;
                        d59 = d58;
                    } else {
                        v59 = v72 + p59;
                        d59 = d72;
                    }
                } else {
                    if (v71 > v58) {
                        v59 = v58 + p59;
                        d59 = d58;
                    } else {
                        v59 = v71 + p59;
                        d59 = d71;
                    }
                }
            }
            if (rc.onTheMap(l69)) {
                p69 = 10 + rc.senseRubble(l69);
                if (v83 > v70) {
                    if (v70 > v82) {
                        if (v82 > v57) {
                            v69 = v57 + p69;
                            d69 = d57;
                        } else {
                            v69 = v82 + p69;
                            d69 = d82;
                        }
                    } else {
                        if (v70 > v57) {
                            v69 = v57 + p69;
                            d69 = d57;
                        } else {
                            v69 = v70 + p69;
                            d69 = d70;
                        }
                    }
                } else {
                    if (v83 > v82) {
                        if (v82 > v57) {
                            v69 = v57 + p69;
                            d69 = d57;
                        } else {
                            v69 = v82 + p69;
                            d69 = d82;
                        }
                    } else {
                        if (v83 > v57) {
                            v69 = v57 + p69;
                            d69 = d57;
                        } else {
                            v69 = v83 + p69;
                            d69 = d83;
                        }
                    }
                }
            }
            if (rc.onTheMap(l73)) {
                p73 = 10 + rc.senseRubble(l73);
                if (v85 > v72) {
                    if (v72 > v86) {
                        if (v86 > v59) {
                            v73 = v59 + p73;
                            d73 = d59;
                        } else {
                            v73 = v86 + p73;
                            d73 = d86;
                        }
                    } else {
                        if (v72 > v59) {
                            v73 = v59 + p73;
                            d73 = d59;
                        } else {
                            v73 = v72 + p73;
                            d73 = d72;
                        }
                    }
                } else {
                    if (v85 > v86) {
                        if (v86 > v59) {
                            v73 = v59 + p73;
                            d73 = d59;
                        } else {
                            v73 = v86 + p73;
                            d73 = d86;
                        }
                    } else {
                        if (v85 > v59) {
                            v73 = v59 + p73;
                            d73 = d59;
                        } else {
                            v73 = v85 + p73;
                            d73 = d85;
                        }
                    }
                }
            }
            if (rc.onTheMap(l95)) {
                p95 = 10 + rc.senseRubble(l95);
                if (v83 > v96) {
                    if (v96 > v82) {
                        v95 = v82 + p95;
                        d95 = d82;
                    } else {
                        v95 = v96 + p95;
                        d95 = d96;
                    }
                } else {
                    if (v83 > v82) {
                        v95 = v82 + p95;
                        d95 = d82;
                    } else {
                        v95 = v83 + p95;
                        d95 = d83;
                    }
                }
            }
            if (rc.onTheMap(l99)) {
                p99 = 10 + rc.senseRubble(l99);
                if (v85 > v98) {
                    if (v98 > v86) {
                        v99 = v86 + p99;
                        d99 = d86;
                    } else {
                        v99 = v98 + p99;
                        d99 = d98;
                    }
                } else {
                    if (v85 > v86) {
                        v99 = v86 + p99;
                        d99 = d86;
                    } else {
                        v99 = v85 + p99;
                        d99 = d85;
                    }
                }
            }
            if (rc.onTheMap(l109)) {
                p109 = 10 + rc.senseRubble(l109);
                if (v97 > v96) {
                    if (v96 > v110) {
                        if (v110 > v95) {
                            v109 = v95 + p109;
                            d109 = d95;
                        } else {
                            v109 = v110 + p109;
                            d109 = d110;
                        }
                    } else {
                        if (v96 > v95) {
                            v109 = v95 + p109;
                            d109 = d95;
                        } else {
                            v109 = v96 + p109;
                            d109 = d96;
                        }
                    }
                } else {
                    if (v97 > v110) {
                        if (v110 > v95) {
                            v109 = v95 + p109;
                            d109 = d95;
                        } else {
                            v109 = v110 + p109;
                            d109 = d110;
                        }
                    } else {
                        if (v97 > v95) {
                            v109 = v95 + p109;
                            d109 = d95;
                        } else {
                            v109 = v97 + p109;
                            d109 = d97;
                        }
                    }
                }
            }
            if (rc.onTheMap(l111)) {
                p111 = 10 + rc.senseRubble(l111);
                if (v97 > v98) {
                    if (v98 > v110) {
                        if (v110 > v99) {
                            v111 = v99 + p111;
                            d111 = d99;
                        } else {
                            v111 = v110 + p111;
                            d111 = d110;
                        }
                    } else {
                        if (v98 > v99) {
                            v111 = v99 + p111;
                            d111 = d99;
                        } else {
                            v111 = v98 + p111;
                            d111 = d98;
                        }
                    }
                } else {
                    if (v97 > v110) {
                        if (v110 > v99) {
                            v111 = v99 + p111;
                            d111 = d99;
                        } else {
                            v111 = v110 + p111;
                            d111 = d110;
                        }
                    } else {
                        if (v97 > v99) {
                            v111 = v99 + p111;
                            d111 = d99;
                        } else {
                            v111 = v97 + p111;
                            d111 = d97;
                        }
                    }
                }
            }
            if (rc.onTheMap(l56)) {
                p56 = 10 + rc.senseRubble(l56);
                if (v70 > v57) {
                    if (v57 > v69) {
                        v56 = v69 + p56;
                        d56 = d69;
                    } else {
                        v56 = v57 + p56;
                        d56 = d57;
                    }
                } else {
                    if (v70 > v69) {
                        v56 = v69 + p56;
                        d56 = d69;
                    } else {
                        v56 = v70 + p56;
                        d56 = d70;
                    }
                }
            }
            if (rc.onTheMap(l60)) {
                p60 = 10 + rc.senseRubble(l60);
                if (v72 > v59) {
                    if (v59 > v73) {
                        v60 = v73 + p60;
                        d60 = d73;
                    } else {
                        v60 = v59 + p60;
                        d60 = d59;
                    }
                } else {
                    if (v72 > v73) {
                        v60 = v73 + p60;
                        d60 = d73;
                    } else {
                        v60 = v72 + p60;
                        d60 = d72;
                    }
                }
            }
            if (rc.onTheMap(l108)) {
                p108 = 10 + rc.senseRubble(l108);
                if (v96 > v109) {
                    if (v109 > v95) {
                        v108 = v95 + p108;
                        d108 = d95;
                    } else {
                        v108 = v109 + p108;
                        d108 = d109;
                    }
                } else {
                    if (v96 > v95) {
                        v108 = v95 + p108;
                        d108 = d95;
                    } else {
                        v108 = v96 + p108;
                        d108 = d96;
                    }
                }
            }
            if (rc.onTheMap(l112)) {
                p112 = 10 + rc.senseRubble(l112);
                if (v98 > v99) {
                    if (v99 > v111) {
                        v112 = v111 + p112;
                        d112 = d111;
                    } else {
                        v112 = v99 + p112;
                        d112 = d99;
                    }
                } else {
                    if (v98 > v111) {
                        v112 = v111 + p112;
                        d112 = d111;
                    } else {
                        v112 = v98 + p112;
                        d112 = d98;
                    }
                }
            }
            if (rc.onTheMap(l45)) {
                p45 = 10 + rc.senseRubble(l45);
                if (v58 > v57) {
                    if (v57 > v59) {
                        v45 = v59 + p45;
                        d45 = d59;
                    } else {
                        v45 = v57 + p45;
                        d45 = d57;
                    }
                } else {
                    if (v58 > v59) {
                        v45 = v59 + p45;
                        d45 = d59;
                    } else {
                        v45 = v58 + p45;
                        d45 = d58;
                    }
                }
            }
            if (rc.onTheMap(l81)) {
                p81 = 10 + rc.senseRubble(l81);
                if (v82 > v69) {
                    if (v69 > v95) {
                        v81 = v95 + p81;
                        d81 = d95;
                    } else {
                        v81 = v69 + p81;
                        d81 = d69;
                    }
                } else {
                    if (v82 > v95) {
                        v81 = v95 + p81;
                        d81 = d95;
                    } else {
                        v81 = v82 + p81;
                        d81 = d82;
                    }
                }
            }
            if (rc.onTheMap(l87)) {
                p87 = 10 + rc.senseRubble(l87);
                if (v86 > v73) {
                    if (v73 > v99) {
                        v87 = v99 + p87;
                        d87 = d99;
                    } else {
                        v87 = v73 + p87;
                        d87 = d73;
                    }
                } else {
                    if (v86 > v99) {
                        v87 = v99 + p87;
                        d87 = d99;
                    } else {
                        v87 = v86 + p87;
                        d87 = d86;
                    }
                }
            }
            if (rc.onTheMap(l123)) {
                p123 = 10 + rc.senseRubble(l123);
                if (v110 > v111) {
                    if (v111 > v109) {
                        v123 = v109 + p123;
                        d123 = d109;
                    } else {
                        v123 = v111 + p123;
                        d123 = d111;
                    }
                } else {
                    if (v110 > v109) {
                        v123 = v109 + p123;
                        d123 = d109;
                    } else {
                        v123 = v110 + p123;
                        d123 = d110;
                    }
                }
            }
            if (rc.onTheMap(l44)) {
                p44 = 10 + rc.senseRubble(l44);
                if (v58 > v57) {
                    if (v57 > v56) {
                        if (v56 > v45) {
                            v44 = v45 + p44;
                            d44 = d45;
                        } else {
                            v44 = v56 + p44;
                            d44 = d56;
                        }
                    } else {
                        if (v57 > v45) {
                            v44 = v45 + p44;
                            d44 = d45;
                        } else {
                            v44 = v57 + p44;
                            d44 = d57;
                        }
                    }
                } else {
                    if (v58 > v56) {
                        if (v56 > v45) {
                            v44 = v45 + p44;
                            d44 = d45;
                        } else {
                            v44 = v56 + p44;
                            d44 = d56;
                        }
                    } else {
                        if (v58 > v45) {
                            v44 = v45 + p44;
                            d44 = d45;
                        } else {
                            v44 = v58 + p44;
                            d44 = d58;
                        }
                    }
                }
            }
            if (rc.onTheMap(l46)) {
                p46 = 10 + rc.senseRubble(l46);
                if (v58 > v59) {
                    if (v59 > v60) {
                        if (v60 > v45) {
                            v46 = v45 + p46;
                            d46 = d45;
                        } else {
                            v46 = v60 + p46;
                            d46 = d60;
                        }
                    } else {
                        if (v59 > v45) {
                            v46 = v45 + p46;
                            d46 = d45;
                        } else {
                            v46 = v59 + p46;
                            d46 = d59;
                        }
                    }
                } else {
                    if (v58 > v60) {
                        if (v60 > v45) {
                            v46 = v45 + p46;
                            d46 = d45;
                        } else {
                            v46 = v60 + p46;
                            d46 = d60;
                        }
                    } else {
                        if (v58 > v45) {
                            v46 = v45 + p46;
                            d46 = d45;
                        } else {
                            v46 = v58 + p46;
                            d46 = d58;
                        }
                    }
                }
            }
            if (rc.onTheMap(l68)) {
                p68 = 10 + rc.senseRubble(l68);
                if (v82 > v69) {
                    if (v69 > v56) {
                        if (v56 > v81) {
                            v68 = v81 + p68;
                            d68 = d81;
                        } else {
                            v68 = v56 + p68;
                            d68 = d56;
                        }
                    } else {
                        if (v69 > v81) {
                            v68 = v81 + p68;
                            d68 = d81;
                        } else {
                            v68 = v69 + p68;
                            d68 = d69;
                        }
                    }
                } else {
                    if (v82 > v56) {
                        if (v56 > v81) {
                            v68 = v81 + p68;
                            d68 = d81;
                        } else {
                            v68 = v56 + p68;
                            d68 = d56;
                        }
                    } else {
                        if (v82 > v81) {
                            v68 = v81 + p68;
                            d68 = d81;
                        } else {
                            v68 = v82 + p68;
                            d68 = d82;
                        }
                    }
                }
            }
            if (rc.onTheMap(l74)) {
                p74 = 10 + rc.senseRubble(l74);
                if (v86 > v73) {
                    if (v73 > v60) {
                        if (v60 > v87) {
                            v74 = v87 + p74;
                            d74 = d87;
                        } else {
                            v74 = v60 + p74;
                            d74 = d60;
                        }
                    } else {
                        if (v73 > v87) {
                            v74 = v87 + p74;
                            d74 = d87;
                        } else {
                            v74 = v73 + p74;
                            d74 = d73;
                        }
                    }
                } else {
                    if (v86 > v60) {
                        if (v60 > v87) {
                            v74 = v87 + p74;
                            d74 = d87;
                        } else {
                            v74 = v60 + p74;
                            d74 = d60;
                        }
                    } else {
                        if (v86 > v87) {
                            v74 = v87 + p74;
                            d74 = d87;
                        } else {
                            v74 = v86 + p74;
                            d74 = d86;
                        }
                    }
                }
            }
            if (rc.onTheMap(l94)) {
                p94 = 10 + rc.senseRubble(l94);
                if (v82 > v95) {
                    if (v95 > v108) {
                        if (v108 > v81) {
                            v94 = v81 + p94;
                            d94 = d81;
                        } else {
                            v94 = v108 + p94;
                            d94 = d108;
                        }
                    } else {
                        if (v95 > v81) {
                            v94 = v81 + p94;
                            d94 = d81;
                        } else {
                            v94 = v95 + p94;
                            d94 = d95;
                        }
                    }
                } else {
                    if (v82 > v108) {
                        if (v108 > v81) {
                            v94 = v81 + p94;
                            d94 = d81;
                        } else {
                            v94 = v108 + p94;
                            d94 = d108;
                        }
                    } else {
                        if (v82 > v81) {
                            v94 = v81 + p94;
                            d94 = d81;
                        } else {
                            v94 = v82 + p94;
                            d94 = d82;
                        }
                    }
                }
            }
            if (rc.onTheMap(l100)) {
                p100 = 10 + rc.senseRubble(l100);
                if (v86 > v99) {
                    if (v99 > v112) {
                        if (v112 > v87) {
                            v100 = v87 + p100;
                            d100 = d87;
                        } else {
                            v100 = v112 + p100;
                            d100 = d112;
                        }
                    } else {
                        if (v99 > v87) {
                            v100 = v87 + p100;
                            d100 = d87;
                        } else {
                            v100 = v99 + p100;
                            d100 = d99;
                        }
                    }
                } else {
                    if (v86 > v112) {
                        if (v112 > v87) {
                            v100 = v87 + p100;
                            d100 = d87;
                        } else {
                            v100 = v112 + p100;
                            d100 = d112;
                        }
                    } else {
                        if (v86 > v87) {
                            v100 = v87 + p100;
                            d100 = d87;
                        } else {
                            v100 = v86 + p100;
                            d100 = d86;
                        }
                    }
                }
            }
            if (rc.onTheMap(l122)) {
                p122 = 10 + rc.senseRubble(l122);
                if (v110 > v109) {
                    if (v109 > v108) {
                        if (v108 > v123) {
                            v122 = v123 + p122;
                            d122 = d123;
                        } else {
                            v122 = v108 + p122;
                            d122 = d108;
                        }
                    } else {
                        if (v109 > v123) {
                            v122 = v123 + p122;
                            d122 = d123;
                        } else {
                            v122 = v109 + p122;
                            d122 = d109;
                        }
                    }
                } else {
                    if (v110 > v108) {
                        if (v108 > v123) {
                            v122 = v123 + p122;
                            d122 = d123;
                        } else {
                            v122 = v108 + p122;
                            d122 = d108;
                        }
                    } else {
                        if (v110 > v123) {
                            v122 = v123 + p122;
                            d122 = d123;
                        } else {
                            v122 = v110 + p122;
                            d122 = d110;
                        }
                    }
                }
            }
            if (rc.onTheMap(l124)) {
                p124 = 10 + rc.senseRubble(l124);
                if (v110 > v111) {
                    if (v111 > v112) {
                        if (v112 > v123) {
                            v124 = v123 + p124;
                            d124 = d123;
                        } else {
                            v124 = v112 + p124;
                            d124 = d112;
                        }
                    } else {
                        if (v111 > v123) {
                            v124 = v123 + p124;
                            d124 = d123;
                        } else {
                            v124 = v111 + p124;
                            d124 = d111;
                        }
                    }
                } else {
                    if (v110 > v112) {
                        if (v112 > v123) {
                            v124 = v123 + p124;
                            d124 = d123;
                        } else {
                            v124 = v112 + p124;
                            d124 = d112;
                        }
                    } else {
                        if (v110 > v123) {
                            v124 = v123 + p124;
                            d124 = d123;
                        } else {
                            v124 = v110 + p124;
                            d124 = d110;
                        }
                    }
                }
            }
            if (rc.onTheMap(l43)) {
                p43 = 10 + rc.senseRubble(l43);
                if (v57 > v56) {
                    if (v56 > v44) {
                        v43 = v44 + p43;
                        d43 = d44;
                    } else {
                        v43 = v56 + p43;
                        d43 = d56;
                    }
                } else {
                    if (v57 > v44) {
                        v43 = v44 + p43;
                        d43 = d44;
                    } else {
                        v43 = v57 + p43;
                        d43 = d57;
                    }
                }
            }
            if (rc.onTheMap(l47)) {
                p47 = 10 + rc.senseRubble(l47);
                if (v59 > v60) {
                    if (v60 > v46) {
                        v47 = v46 + p47;
                        d47 = d46;
                    } else {
                        v47 = v60 + p47;
                        d47 = d60;
                    }
                } else {
                    if (v59 > v46) {
                        v47 = v46 + p47;
                        d47 = d46;
                    } else {
                        v47 = v59 + p47;
                        d47 = d59;
                    }
                }
            }
            if (rc.onTheMap(l55)) {
                p55 = 10 + rc.senseRubble(l55);
                if (v69 > v56) {
                    if (v56 > v68) {
                        if (v68 > v43) {
                            v55 = v43 + p55;
                            d55 = d43;
                        } else {
                            v55 = v68 + p55;
                            d55 = d68;
                        }
                    } else {
                        if (v56 > v43) {
                            v55 = v43 + p55;
                            d55 = d43;
                        } else {
                            v55 = v56 + p55;
                            d55 = d56;
                        }
                    }
                } else {
                    if (v69 > v68) {
                        if (v68 > v43) {
                            v55 = v43 + p55;
                            d55 = d43;
                        } else {
                            v55 = v68 + p55;
                            d55 = d68;
                        }
                    } else {
                        if (v69 > v43) {
                            v55 = v43 + p55;
                            d55 = d43;
                        } else {
                            v55 = v69 + p55;
                            d55 = d69;
                        }
                    }
                }
            }
            if (rc.onTheMap(l61)) {
                p61 = 10 + rc.senseRubble(l61);
                if (v73 > v60) {
                    if (v60 > v74) {
                        if (v74 > v47) {
                            v61 = v47 + p61;
                            d61 = d47;
                        } else {
                            v61 = v74 + p61;
                            d61 = d74;
                        }
                    } else {
                        if (v60 > v47) {
                            v61 = v47 + p61;
                            d61 = d47;
                        } else {
                            v61 = v60 + p61;
                            d61 = d60;
                        }
                    }
                } else {
                    if (v73 > v74) {
                        if (v74 > v47) {
                            v61 = v47 + p61;
                            d61 = d47;
                        } else {
                            v61 = v74 + p61;
                            d61 = d74;
                        }
                    } else {
                        if (v73 > v47) {
                            v61 = v47 + p61;
                            d61 = d47;
                        } else {
                            v61 = v73 + p61;
                            d61 = d73;
                        }
                    }
                }
            }
            if (rc.onTheMap(l107)) {
                p107 = 10 + rc.senseRubble(l107);
                if (v95 > v108) {
                    if (v108 > v94) {
                        v107 = v94 + p107;
                        d107 = d94;
                    } else {
                        v107 = v108 + p107;
                        d107 = d108;
                    }
                } else {
                    if (v95 > v94) {
                        v107 = v94 + p107;
                        d107 = d94;
                    } else {
                        v107 = v95 + p107;
                        d107 = d95;
                    }
                }
            }
            if (rc.onTheMap(l113)) {
                p113 = 10 + rc.senseRubble(l113);
                if (v99 > v112) {
                    if (v112 > v100) {
                        v113 = v100 + p113;
                        d113 = d100;
                    } else {
                        v113 = v112 + p113;
                        d113 = d112;
                    }
                } else {
                    if (v99 > v100) {
                        v113 = v100 + p113;
                        d113 = d100;
                    } else {
                        v113 = v99 + p113;
                        d113 = d99;
                    }
                }
            }
            if (rc.onTheMap(l121)) {
                p121 = 10 + rc.senseRubble(l121);
                if (v109 > v108) {
                    if (v108 > v122) {
                        if (v122 > v107) {
                            v121 = v107 + p121;
                            d121 = d107;
                        } else {
                            v121 = v122 + p121;
                            d121 = d122;
                        }
                    } else {
                        if (v108 > v107) {
                            v121 = v107 + p121;
                            d121 = d107;
                        } else {
                            v121 = v108 + p121;
                            d121 = d108;
                        }
                    }
                } else {
                    if (v109 > v122) {
                        if (v122 > v107) {
                            v121 = v107 + p121;
                            d121 = d107;
                        } else {
                            v121 = v122 + p121;
                            d121 = d122;
                        }
                    } else {
                        if (v109 > v107) {
                            v121 = v107 + p121;
                            d121 = d107;
                        } else {
                            v121 = v109 + p121;
                            d121 = d109;
                        }
                    }
                }
            }
            if (rc.onTheMap(l125)) {
                p125 = 10 + rc.senseRubble(l125);
                if (v111 > v112) {
                    if (v112 > v124) {
                        if (v124 > v113) {
                            v125 = v113 + p125;
                            d125 = d113;
                        } else {
                            v125 = v124 + p125;
                            d125 = d124;
                        }
                    } else {
                        if (v112 > v113) {
                            v125 = v113 + p125;
                            d125 = d113;
                        } else {
                            v125 = v112 + p125;
                            d125 = d112;
                        }
                    }
                } else {
                    if (v111 > v124) {
                        if (v124 > v113) {
                            v125 = v113 + p125;
                            d125 = d113;
                        } else {
                            v125 = v124 + p125;
                            d125 = d124;
                        }
                    } else {
                        if (v111 > v113) {
                            v125 = v113 + p125;
                            d125 = d113;
                        } else {
                            v125 = v111 + p125;
                            d125 = d111;
                        }
                    }
                }
            }
            if (rc.onTheMap(l32)) {
                p32 = 10 + rc.senseRubble(l32);
                if (v45 > v44) {
                    if (v44 > v46) {
                        v32 = v46 + p32;
                        d32 = d46;
                    } else {
                        v32 = v44 + p32;
                        d32 = d44;
                    }
                } else {
                    if (v45 > v46) {
                        v32 = v46 + p32;
                        d32 = d46;
                    } else {
                        v32 = v45 + p32;
                        d32 = d45;
                    }
                }
            }
            if (rc.onTheMap(l80)) {
                p80 = 10 + rc.senseRubble(l80);
                if (v81 > v68) {
                    if (v68 > v94) {
                        v80 = v94 + p80;
                        d80 = d94;
                    } else {
                        v80 = v68 + p80;
                        d80 = d68;
                    }
                } else {
                    if (v81 > v94) {
                        v80 = v94 + p80;
                        d80 = d94;
                    } else {
                        v80 = v81 + p80;
                        d80 = d81;
                    }
                }
            }
            if (rc.onTheMap(l88)) {
                p88 = 10 + rc.senseRubble(l88);
                if (v87 > v74) {
                    if (v74 > v100) {
                        v88 = v100 + p88;
                        d88 = d100;
                    } else {
                        v88 = v74 + p88;
                        d88 = d74;
                    }
                } else {
                    if (v87 > v100) {
                        v88 = v100 + p88;
                        d88 = d100;
                    } else {
                        v88 = v87 + p88;
                        d88 = d87;
                    }
                }
            }
            if (rc.onTheMap(l136)) {
                p136 = 10 + rc.senseRubble(l136);
                if (v123 > v124) {
                    if (v124 > v122) {
                        v136 = v122 + p136;
                        d136 = d122;
                    } else {
                        v136 = v124 + p136;
                        d136 = d124;
                    }
                } else {
                    if (v123 > v122) {
                        v136 = v122 + p136;
                        d136 = d122;
                    } else {
                        v136 = v123 + p136;
                        d136 = d123;
                    }
                }
            }
            if (rc.onTheMap(l31)) {
                p31 = 10 + rc.senseRubble(l31);
                if (v45 > v44) {
                    if (v44 > v43) {
                        if (v43 > v32) {
                            v31 = v32 + p31;
                            d31 = d32;
                        } else {
                            v31 = v43 + p31;
                            d31 = d43;
                        }
                    } else {
                        if (v44 > v32) {
                            v31 = v32 + p31;
                            d31 = d32;
                        } else {
                            v31 = v44 + p31;
                            d31 = d44;
                        }
                    }
                } else {
                    if (v45 > v43) {
                        if (v43 > v32) {
                            v31 = v32 + p31;
                            d31 = d32;
                        } else {
                            v31 = v43 + p31;
                            d31 = d43;
                        }
                    } else {
                        if (v45 > v32) {
                            v31 = v32 + p31;
                            d31 = d32;
                        } else {
                            v31 = v45 + p31;
                            d31 = d45;
                        }
                    }
                }
            }
            if (rc.onTheMap(l33)) {
                p33 = 10 + rc.senseRubble(l33);
                if (v45 > v46) {
                    if (v46 > v47) {
                        if (v47 > v32) {
                            v33 = v32 + p33;
                            d33 = d32;
                        } else {
                            v33 = v47 + p33;
                            d33 = d47;
                        }
                    } else {
                        if (v46 > v32) {
                            v33 = v32 + p33;
                            d33 = d32;
                        } else {
                            v33 = v46 + p33;
                            d33 = d46;
                        }
                    }
                } else {
                    if (v45 > v47) {
                        if (v47 > v32) {
                            v33 = v32 + p33;
                            d33 = d32;
                        } else {
                            v33 = v47 + p33;
                            d33 = d47;
                        }
                    } else {
                        if (v45 > v32) {
                            v33 = v32 + p33;
                            d33 = d32;
                        } else {
                            v33 = v45 + p33;
                            d33 = d45;
                        }
                    }
                }
            }
            if (rc.onTheMap(l67)) {
                p67 = 10 + rc.senseRubble(l67);
                if (v81 > v68) {
                    if (v68 > v55) {
                        if (v55 > v80) {
                            v67 = v80 + p67;
                            d67 = d80;
                        } else {
                            v67 = v55 + p67;
                            d67 = d55;
                        }
                    } else {
                        if (v68 > v80) {
                            v67 = v80 + p67;
                            d67 = d80;
                        } else {
                            v67 = v68 + p67;
                            d67 = d68;
                        }
                    }
                } else {
                    if (v81 > v55) {
                        if (v55 > v80) {
                            v67 = v80 + p67;
                            d67 = d80;
                        } else {
                            v67 = v55 + p67;
                            d67 = d55;
                        }
                    } else {
                        if (v81 > v80) {
                            v67 = v80 + p67;
                            d67 = d80;
                        } else {
                            v67 = v81 + p67;
                            d67 = d81;
                        }
                    }
                }
            }
            if (rc.onTheMap(l75)) {
                p75 = 10 + rc.senseRubble(l75);
                if (v87 > v74) {
                    if (v74 > v61) {
                        if (v61 > v88) {
                            v75 = v88 + p75;
                            d75 = d88;
                        } else {
                            v75 = v61 + p75;
                            d75 = d61;
                        }
                    } else {
                        if (v74 > v88) {
                            v75 = v88 + p75;
                            d75 = d88;
                        } else {
                            v75 = v74 + p75;
                            d75 = d74;
                        }
                    }
                } else {
                    if (v87 > v61) {
                        if (v61 > v88) {
                            v75 = v88 + p75;
                            d75 = d88;
                        } else {
                            v75 = v61 + p75;
                            d75 = d61;
                        }
                    } else {
                        if (v87 > v88) {
                            v75 = v88 + p75;
                            d75 = d88;
                        } else {
                            v75 = v87 + p75;
                            d75 = d87;
                        }
                    }
                }
            }
            if (rc.onTheMap(l93)) {
                p93 = 10 + rc.senseRubble(l93);
                if (v81 > v94) {
                    if (v94 > v107) {
                        if (v107 > v80) {
                            v93 = v80 + p93;
                            d93 = d80;
                        } else {
                            v93 = v107 + p93;
                            d93 = d107;
                        }
                    } else {
                        if (v94 > v80) {
                            v93 = v80 + p93;
                            d93 = d80;
                        } else {
                            v93 = v94 + p93;
                            d93 = d94;
                        }
                    }
                } else {
                    if (v81 > v107) {
                        if (v107 > v80) {
                            v93 = v80 + p93;
                            d93 = d80;
                        } else {
                            v93 = v107 + p93;
                            d93 = d107;
                        }
                    } else {
                        if (v81 > v80) {
                            v93 = v80 + p93;
                            d93 = d80;
                        } else {
                            v93 = v81 + p93;
                            d93 = d81;
                        }
                    }
                }
            }
            if (rc.onTheMap(l101)) {
                p101 = 10 + rc.senseRubble(l101);
                if (v87 > v100) {
                    if (v100 > v113) {
                        if (v113 > v88) {
                            v101 = v88 + p101;
                            d101 = d88;
                        } else {
                            v101 = v113 + p101;
                            d101 = d113;
                        }
                    } else {
                        if (v100 > v88) {
                            v101 = v88 + p101;
                            d101 = d88;
                        } else {
                            v101 = v100 + p101;
                            d101 = d100;
                        }
                    }
                } else {
                    if (v87 > v113) {
                        if (v113 > v88) {
                            v101 = v88 + p101;
                            d101 = d88;
                        } else {
                            v101 = v113 + p101;
                            d101 = d113;
                        }
                    } else {
                        if (v87 > v88) {
                            v101 = v88 + p101;
                            d101 = d88;
                        } else {
                            v101 = v87 + p101;
                            d101 = d87;
                        }
                    }
                }
            }
            if (rc.onTheMap(l135)) {
                p135 = 10 + rc.senseRubble(l135);
                if (v123 > v122) {
                    if (v122 > v121) {
                        if (v121 > v136) {
                            v135 = v136 + p135;
                            d135 = d136;
                        } else {
                            v135 = v121 + p135;
                            d135 = d121;
                        }
                    } else {
                        if (v122 > v136) {
                            v135 = v136 + p135;
                            d135 = d136;
                        } else {
                            v135 = v122 + p135;
                            d135 = d122;
                        }
                    }
                } else {
                    if (v123 > v121) {
                        if (v121 > v136) {
                            v135 = v136 + p135;
                            d135 = d136;
                        } else {
                            v135 = v121 + p135;
                            d135 = d121;
                        }
                    } else {
                        if (v123 > v136) {
                            v135 = v136 + p135;
                            d135 = d136;
                        } else {
                            v135 = v123 + p135;
                            d135 = d123;
                        }
                    }
                }
            }
            if (rc.onTheMap(l137)) {
                p137 = 10 + rc.senseRubble(l137);
                if (v123 > v124) {
                    if (v124 > v125) {
                        if (v125 > v136) {
                            v137 = v136 + p137;
                            d137 = d136;
                        } else {
                            v137 = v125 + p137;
                            d137 = d125;
                        }
                    } else {
                        if (v124 > v136) {
                            v137 = v136 + p137;
                            d137 = d136;
                        } else {
                            v137 = v124 + p137;
                            d137 = d124;
                        }
                    }
                } else {
                    if (v123 > v125) {
                        if (v125 > v136) {
                            v137 = v136 + p137;
                            d137 = d136;
                        } else {
                            v137 = v125 + p137;
                            d137 = d125;
                        }
                    } else {
                        if (v123 > v136) {
                            v137 = v136 + p137;
                            d137 = d136;
                        } else {
                            v137 = v123 + p137;
                            d137 = d123;
                        }
                    }
                }
            }
            if (rc.onTheMap(l42)) {
                p42 = 10 + rc.senseRubble(l42);
                if (v56 > v43) {
                    if (v43 > v55) {
                        v42 = v55 + p42;
                        d42 = d55;
                    } else {
                        v42 = v43 + p42;
                        d42 = d43;
                    }
                } else {
                    if (v56 > v55) {
                        v42 = v55 + p42;
                        d42 = d55;
                    } else {
                        v42 = v56 + p42;
                        d42 = d56;
                    }
                }
            }
            if (rc.onTheMap(l48)) {
                p48 = 10 + rc.senseRubble(l48);
                if (v60 > v47) {
                    if (v47 > v61) {
                        v48 = v61 + p48;
                        d48 = d61;
                    } else {
                        v48 = v47 + p48;
                        d48 = d47;
                    }
                } else {
                    if (v60 > v61) {
                        v48 = v61 + p48;
                        d48 = d61;
                    } else {
                        v48 = v60 + p48;
                        d48 = d60;
                    }
                }
            }
            if (rc.onTheMap(l120)) {
                p120 = 10 + rc.senseRubble(l120);
                if (v108 > v121) {
                    if (v121 > v107) {
                        v120 = v107 + p120;
                        d120 = d107;
                    } else {
                        v120 = v121 + p120;
                        d120 = d121;
                    }
                } else {
                    if (v108 > v107) {
                        v120 = v107 + p120;
                        d120 = d107;
                    } else {
                        v120 = v108 + p120;
                        d120 = d108;
                    }
                }
            }
            if (rc.onTheMap(l126)) {
                p126 = 10 + rc.senseRubble(l126);
                if (v112 > v113) {
                    if (v113 > v125) {
                        v126 = v125 + p126;
                        d126 = d125;
                    } else {
                        v126 = v113 + p126;
                        d126 = d113;
                    }
                } else {
                    if (v112 > v125) {
                        v126 = v125 + p126;
                        d126 = d125;
                    } else {
                        v126 = v112 + p126;
                        d126 = d112;
                    }
                }
            }
            if (rc.onTheMap(l30)) {
                p30 = 10 + rc.senseRubble(l30);
                if (v44 > v43) {
                    if (v43 > v31) {
                        if (v31 > v42) {
                            v30 = v42 + p30;
                            d30 = d42;
                        } else {
                            v30 = v31 + p30;
                            d30 = d31;
                        }
                    } else {
                        if (v43 > v42) {
                            v30 = v42 + p30;
                            d30 = d42;
                        } else {
                            v30 = v43 + p30;
                            d30 = d43;
                        }
                    }
                } else {
                    if (v44 > v31) {
                        if (v31 > v42) {
                            v30 = v42 + p30;
                            d30 = d42;
                        } else {
                            v30 = v31 + p30;
                            d30 = d31;
                        }
                    } else {
                        if (v44 > v42) {
                            v30 = v42 + p30;
                            d30 = d42;
                        } else {
                            v30 = v44 + p30;
                            d30 = d44;
                        }
                    }
                }
            }
            if (rc.onTheMap(l34)) {
                p34 = 10 + rc.senseRubble(l34);
                if (v46 > v47) {
                    if (v47 > v33) {
                        if (v33 > v48) {
                            v34 = v48 + p34;
                            d34 = d48;
                        } else {
                            v34 = v33 + p34;
                            d34 = d33;
                        }
                    } else {
                        if (v47 > v48) {
                            v34 = v48 + p34;
                            d34 = d48;
                        } else {
                            v34 = v47 + p34;
                            d34 = d47;
                        }
                    }
                } else {
                    if (v46 > v33) {
                        if (v33 > v48) {
                            v34 = v48 + p34;
                            d34 = d48;
                        } else {
                            v34 = v33 + p34;
                            d34 = d33;
                        }
                    } else {
                        if (v46 > v48) {
                            v34 = v48 + p34;
                            d34 = d48;
                        } else {
                            v34 = v46 + p34;
                            d34 = d46;
                        }
                    }
                }
            }
            if (rc.onTheMap(l54)) {
                p54 = 10 + rc.senseRubble(l54);
                if (v68 > v55) {
                    if (v55 > v67) {
                        if (v67 > v42) {
                            v54 = v42 + p54;
                            d54 = d42;
                        } else {
                            v54 = v67 + p54;
                            d54 = d67;
                        }
                    } else {
                        if (v55 > v42) {
                            v54 = v42 + p54;
                            d54 = d42;
                        } else {
                            v54 = v55 + p54;
                            d54 = d55;
                        }
                    }
                } else {
                    if (v68 > v67) {
                        if (v67 > v42) {
                            v54 = v42 + p54;
                            d54 = d42;
                        } else {
                            v54 = v67 + p54;
                            d54 = d67;
                        }
                    } else {
                        if (v68 > v42) {
                            v54 = v42 + p54;
                            d54 = d42;
                        } else {
                            v54 = v68 + p54;
                            d54 = d68;
                        }
                    }
                }
            }
            if (rc.onTheMap(l62)) {
                p62 = 10 + rc.senseRubble(l62);
                if (v74 > v61) {
                    if (v61 > v75) {
                        if (v75 > v48) {
                            v62 = v48 + p62;
                            d62 = d48;
                        } else {
                            v62 = v75 + p62;
                            d62 = d75;
                        }
                    } else {
                        if (v61 > v48) {
                            v62 = v48 + p62;
                            d62 = d48;
                        } else {
                            v62 = v61 + p62;
                            d62 = d61;
                        }
                    }
                } else {
                    if (v74 > v75) {
                        if (v75 > v48) {
                            v62 = v48 + p62;
                            d62 = d48;
                        } else {
                            v62 = v75 + p62;
                            d62 = d75;
                        }
                    } else {
                        if (v74 > v48) {
                            v62 = v48 + p62;
                            d62 = d48;
                        } else {
                            v62 = v74 + p62;
                            d62 = d74;
                        }
                    }
                }
            }
            if (rc.onTheMap(l106)) {
                p106 = 10 + rc.senseRubble(l106);
                if (v94 > v107) {
                    if (v107 > v93) {
                        if (v93 > v120) {
                            v106 = v120 + p106;
                            d106 = d120;
                        } else {
                            v106 = v93 + p106;
                            d106 = d93;
                        }
                    } else {
                        if (v107 > v120) {
                            v106 = v120 + p106;
                            d106 = d120;
                        } else {
                            v106 = v107 + p106;
                            d106 = d107;
                        }
                    }
                } else {
                    if (v94 > v93) {
                        if (v93 > v120) {
                            v106 = v120 + p106;
                            d106 = d120;
                        } else {
                            v106 = v93 + p106;
                            d106 = d93;
                        }
                    } else {
                        if (v94 > v120) {
                            v106 = v120 + p106;
                            d106 = d120;
                        } else {
                            v106 = v94 + p106;
                            d106 = d94;
                        }
                    }
                }
            }
            if (rc.onTheMap(l114)) {
                p114 = 10 + rc.senseRubble(l114);
                if (v100 > v113) {
                    if (v113 > v101) {
                        if (v101 > v126) {
                            v114 = v126 + p114;
                            d114 = d126;
                        } else {
                            v114 = v101 + p114;
                            d114 = d101;
                        }
                    } else {
                        if (v113 > v126) {
                            v114 = v126 + p114;
                            d114 = d126;
                        } else {
                            v114 = v113 + p114;
                            d114 = d113;
                        }
                    }
                } else {
                    if (v100 > v101) {
                        if (v101 > v126) {
                            v114 = v126 + p114;
                            d114 = d126;
                        } else {
                            v114 = v101 + p114;
                            d114 = d101;
                        }
                    } else {
                        if (v100 > v126) {
                            v114 = v126 + p114;
                            d114 = d126;
                        } else {
                            v114 = v100 + p114;
                            d114 = d100;
                        }
                    }
                }
            }
            if (rc.onTheMap(l134)) {
                p134 = 10 + rc.senseRubble(l134);
                if (v122 > v121) {
                    if (v121 > v135) {
                        if (v135 > v120) {
                            v134 = v120 + p134;
                            d134 = d120;
                        } else {
                            v134 = v135 + p134;
                            d134 = d135;
                        }
                    } else {
                        if (v121 > v120) {
                            v134 = v120 + p134;
                            d134 = d120;
                        } else {
                            v134 = v121 + p134;
                            d134 = d121;
                        }
                    }
                } else {
                    if (v122 > v135) {
                        if (v135 > v120) {
                            v134 = v120 + p134;
                            d134 = d120;
                        } else {
                            v134 = v135 + p134;
                            d134 = d135;
                        }
                    } else {
                        if (v122 > v120) {
                            v134 = v120 + p134;
                            d134 = d120;
                        } else {
                            v134 = v122 + p134;
                            d134 = d122;
                        }
                    }
                }
            }
            if (rc.onTheMap(l138)) {
                p138 = 10 + rc.senseRubble(l138);
                if (v124 > v125) {
                    if (v125 > v137) {
                        if (v137 > v126) {
                            v138 = v126 + p138;
                            d138 = d126;
                        } else {
                            v138 = v137 + p138;
                            d138 = d137;
                        }
                    } else {
                        if (v125 > v126) {
                            v138 = v126 + p138;
                            d138 = d126;
                        } else {
                            v138 = v125 + p138;
                            d138 = d125;
                        }
                    }
                } else {
                    if (v124 > v137) {
                        if (v137 > v126) {
                            v138 = v126 + p138;
                            d138 = d126;
                        } else {
                            v138 = v137 + p138;
                            d138 = d137;
                        }
                    } else {
                        if (v124 > v126) {
                            v138 = v126 + p138;
                            d138 = d126;
                        } else {
                            v138 = v124 + p138;
                            d138 = d124;
                        }
                    }
                }
            }
            if (rc.onTheMap(l19)) {
                p19 = 10 + rc.senseRubble(l19);
                if (v32 > v31) {
                    if (v31 > v33) {
                        v19 = v33 + p19;
                        d19 = d33;
                    } else {
                        v19 = v31 + p19;
                        d19 = d31;
                    }
                } else {
                    if (v32 > v33) {
                        v19 = v33 + p19;
                        d19 = d33;
                    } else {
                        v19 = v32 + p19;
                        d19 = d32;
                    }
                }
            }
            if (rc.onTheMap(l29)) {
                p29 = 10 + rc.senseRubble(l29);
                if (v43 > v42) {
                    if (v42 > v30) {
                        v29 = v30 + p29;
                        d29 = d30;
                    } else {
                        v29 = v42 + p29;
                        d29 = d42;
                    }
                } else {
                    if (v43 > v30) {
                        v29 = v30 + p29;
                        d29 = d30;
                    } else {
                        v29 = v43 + p29;
                        d29 = d43;
                    }
                }
            }
            if (rc.onTheMap(l35)) {
                p35 = 10 + rc.senseRubble(l35);
                if (v47 > v48) {
                    if (v48 > v34) {
                        v35 = v34 + p35;
                        d35 = d34;
                    } else {
                        v35 = v48 + p35;
                        d35 = d48;
                    }
                } else {
                    if (v47 > v34) {
                        v35 = v34 + p35;
                        d35 = d34;
                    } else {
                        v35 = v47 + p35;
                        d35 = d47;
                    }
                }
            }
            if (rc.onTheMap(l41)) {
                p41 = 10 + rc.senseRubble(l41);
                if (v55 > v42) {
                    if (v42 > v54) {
                        if (v54 > v29) {
                            v41 = v29 + p41;
                            d41 = d29;
                        } else {
                            v41 = v54 + p41;
                            d41 = d54;
                        }
                    } else {
                        if (v42 > v29) {
                            v41 = v29 + p41;
                            d41 = d29;
                        } else {
                            v41 = v42 + p41;
                            d41 = d42;
                        }
                    }
                } else {
                    if (v55 > v54) {
                        if (v54 > v29) {
                            v41 = v29 + p41;
                            d41 = d29;
                        } else {
                            v41 = v54 + p41;
                            d41 = d54;
                        }
                    } else {
                        if (v55 > v29) {
                            v41 = v29 + p41;
                            d41 = d29;
                        } else {
                            v41 = v55 + p41;
                            d41 = d55;
                        }
                    }
                }
            }
            if (rc.onTheMap(l49)) {
                p49 = 10 + rc.senseRubble(l49);
                if (v61 > v48) {
                    if (v48 > v62) {
                        if (v62 > v35) {
                            v49 = v35 + p49;
                            d49 = d35;
                        } else {
                            v49 = v62 + p49;
                            d49 = d62;
                        }
                    } else {
                        if (v48 > v35) {
                            v49 = v35 + p49;
                            d49 = d35;
                        } else {
                            v49 = v48 + p49;
                            d49 = d48;
                        }
                    }
                } else {
                    if (v61 > v62) {
                        if (v62 > v35) {
                            v49 = v35 + p49;
                            d49 = d35;
                        } else {
                            v49 = v62 + p49;
                            d49 = d62;
                        }
                    } else {
                        if (v61 > v35) {
                            v49 = v35 + p49;
                            d49 = d35;
                        } else {
                            v49 = v61 + p49;
                            d49 = d61;
                        }
                    }
                }
            }
            if (rc.onTheMap(l79)) {
                p79 = 10 + rc.senseRubble(l79);
                if (v80 > v67) {
                    if (v67 > v93) {
                        v79 = v93 + p79;
                        d79 = d93;
                    } else {
                        v79 = v67 + p79;
                        d79 = d67;
                    }
                } else {
                    if (v80 > v93) {
                        v79 = v93 + p79;
                        d79 = d93;
                    } else {
                        v79 = v80 + p79;
                        d79 = d80;
                    }
                }
            }
            if (rc.onTheMap(l89)) {
                p89 = 10 + rc.senseRubble(l89);
                if (v88 > v75) {
                    if (v75 > v101) {
                        v89 = v101 + p89;
                        d89 = d101;
                    } else {
                        v89 = v75 + p89;
                        d89 = d75;
                    }
                } else {
                    if (v88 > v101) {
                        v89 = v101 + p89;
                        d89 = d101;
                    } else {
                        v89 = v88 + p89;
                        d89 = d88;
                    }
                }
            }
            if (rc.onTheMap(l119)) {
                p119 = 10 + rc.senseRubble(l119);
                if (v107 > v120) {
                    if (v120 > v106) {
                        v119 = v106 + p119;
                        d119 = d106;
                    } else {
                        v119 = v120 + p119;
                        d119 = d120;
                    }
                } else {
                    if (v107 > v106) {
                        v119 = v106 + p119;
                        d119 = d106;
                    } else {
                        v119 = v107 + p119;
                        d119 = d107;
                    }
                }
            }
            if (rc.onTheMap(l127)) {
                p127 = 10 + rc.senseRubble(l127);
                if (v113 > v126) {
                    if (v126 > v114) {
                        v127 = v114 + p127;
                        d127 = d114;
                    } else {
                        v127 = v126 + p127;
                        d127 = d126;
                    }
                } else {
                    if (v113 > v114) {
                        v127 = v114 + p127;
                        d127 = d114;
                    } else {
                        v127 = v113 + p127;
                        d127 = d113;
                    }
                }
            }
            if (rc.onTheMap(l133)) {
                p133 = 10 + rc.senseRubble(l133);
                if (v121 > v120) {
                    if (v120 > v134) {
                        if (v134 > v119) {
                            v133 = v119 + p133;
                            d133 = d119;
                        } else {
                            v133 = v134 + p133;
                            d133 = d134;
                        }
                    } else {
                        if (v120 > v119) {
                            v133 = v119 + p133;
                            d133 = d119;
                        } else {
                            v133 = v120 + p133;
                            d133 = d120;
                        }
                    }
                } else {
                    if (v121 > v134) {
                        if (v134 > v119) {
                            v133 = v119 + p133;
                            d133 = d119;
                        } else {
                            v133 = v134 + p133;
                            d133 = d134;
                        }
                    } else {
                        if (v121 > v119) {
                            v133 = v119 + p133;
                            d133 = d119;
                        } else {
                            v133 = v121 + p133;
                            d133 = d121;
                        }
                    }
                }
            }
            if (rc.onTheMap(l139)) {
                p139 = 10 + rc.senseRubble(l139);
                if (v125 > v126) {
                    if (v126 > v138) {
                        if (v138 > v127) {
                            v139 = v127 + p139;
                            d139 = d127;
                        } else {
                            v139 = v138 + p139;
                            d139 = d138;
                        }
                    } else {
                        if (v126 > v127) {
                            v139 = v127 + p139;
                            d139 = d127;
                        } else {
                            v139 = v126 + p139;
                            d139 = d126;
                        }
                    }
                } else {
                    if (v125 > v138) {
                        if (v138 > v127) {
                            v139 = v127 + p139;
                            d139 = d127;
                        } else {
                            v139 = v138 + p139;
                            d139 = d138;
                        }
                    } else {
                        if (v125 > v127) {
                            v139 = v127 + p139;
                            d139 = d127;
                        } else {
                            v139 = v125 + p139;
                            d139 = d125;
                        }
                    }
                }
            }
            if (rc.onTheMap(l149)) {
                p149 = 10 + rc.senseRubble(l149);
                if (v136 > v137) {
                    if (v137 > v135) {
                        v149 = v135 + p149;
                        d149 = d135;
                    } else {
                        v149 = v137 + p149;
                        d149 = d137;
                    }
                } else {
                    if (v136 > v135) {
                        v149 = v135 + p149;
                        d149 = d135;
                    } else {
                        v149 = v136 + p149;
                        d149 = d136;
                    }
                }
            }
            if (rc.onTheMap(l18)) {
                p18 = 10 + rc.senseRubble(l18);
                if (v32 > v31) {
                    if (v31 > v30) {
                        if (v30 > v19) {
                            v18 = v19 + p18;
                            d18 = d19;
                        } else {
                            v18 = v30 + p18;
                            d18 = d30;
                        }
                    } else {
                        if (v31 > v19) {
                            v18 = v19 + p18;
                            d18 = d19;
                        } else {
                            v18 = v31 + p18;
                            d18 = d31;
                        }
                    }
                } else {
                    if (v32 > v30) {
                        if (v30 > v19) {
                            v18 = v19 + p18;
                            d18 = d19;
                        } else {
                            v18 = v30 + p18;
                            d18 = d30;
                        }
                    } else {
                        if (v32 > v19) {
                            v18 = v19 + p18;
                            d18 = d19;
                        } else {
                            v18 = v32 + p18;
                            d18 = d32;
                        }
                    }
                }
            }
            if (rc.onTheMap(l20)) {
                p20 = 10 + rc.senseRubble(l20);
                if (v32 > v33) {
                    if (v33 > v34) {
                        if (v34 > v19) {
                            v20 = v19 + p20;
                            d20 = d19;
                        } else {
                            v20 = v34 + p20;
                            d20 = d34;
                        }
                    } else {
                        if (v33 > v19) {
                            v20 = v19 + p20;
                            d20 = d19;
                        } else {
                            v20 = v33 + p20;
                            d20 = d33;
                        }
                    }
                } else {
                    if (v32 > v34) {
                        if (v34 > v19) {
                            v20 = v19 + p20;
                            d20 = d19;
                        } else {
                            v20 = v34 + p20;
                            d20 = d34;
                        }
                    } else {
                        if (v32 > v19) {
                            v20 = v19 + p20;
                            d20 = d19;
                        } else {
                            v20 = v32 + p20;
                            d20 = d32;
                        }
                    }
                }
            }
            if (rc.onTheMap(l66)) {
                p66 = 10 + rc.senseRubble(l66);
                if (v80 > v67) {
                    if (v67 > v54) {
                        if (v54 > v79) {
                            v66 = v79 + p66;
                            d66 = d79;
                        } else {
                            v66 = v54 + p66;
                            d66 = d54;
                        }
                    } else {
                        if (v67 > v79) {
                            v66 = v79 + p66;
                            d66 = d79;
                        } else {
                            v66 = v67 + p66;
                            d66 = d67;
                        }
                    }
                } else {
                    if (v80 > v54) {
                        if (v54 > v79) {
                            v66 = v79 + p66;
                            d66 = d79;
                        } else {
                            v66 = v54 + p66;
                            d66 = d54;
                        }
                    } else {
                        if (v80 > v79) {
                            v66 = v79 + p66;
                            d66 = d79;
                        } else {
                            v66 = v80 + p66;
                            d66 = d80;
                        }
                    }
                }
            }
            if (rc.onTheMap(l76)) {
                p76 = 10 + rc.senseRubble(l76);
                if (v88 > v75) {
                    if (v75 > v62) {
                        if (v62 > v89) {
                            v76 = v89 + p76;
                            d76 = d89;
                        } else {
                            v76 = v62 + p76;
                            d76 = d62;
                        }
                    } else {
                        if (v75 > v89) {
                            v76 = v89 + p76;
                            d76 = d89;
                        } else {
                            v76 = v75 + p76;
                            d76 = d75;
                        }
                    }
                } else {
                    if (v88 > v62) {
                        if (v62 > v89) {
                            v76 = v89 + p76;
                            d76 = d89;
                        } else {
                            v76 = v62 + p76;
                            d76 = d62;
                        }
                    } else {
                        if (v88 > v89) {
                            v76 = v89 + p76;
                            d76 = d89;
                        } else {
                            v76 = v88 + p76;
                            d76 = d88;
                        }
                    }
                }
            }
            if (rc.onTheMap(l92)) {
                p92 = 10 + rc.senseRubble(l92);
                if (v80 > v93) {
                    if (v93 > v106) {
                        if (v106 > v79) {
                            v92 = v79 + p92;
                            d92 = d79;
                        } else {
                            v92 = v106 + p92;
                            d92 = d106;
                        }
                    } else {
                        if (v93 > v79) {
                            v92 = v79 + p92;
                            d92 = d79;
                        } else {
                            v92 = v93 + p92;
                            d92 = d93;
                        }
                    }
                } else {
                    if (v80 > v106) {
                        if (v106 > v79) {
                            v92 = v79 + p92;
                            d92 = d79;
                        } else {
                            v92 = v106 + p92;
                            d92 = d106;
                        }
                    } else {
                        if (v80 > v79) {
                            v92 = v79 + p92;
                            d92 = d79;
                        } else {
                            v92 = v80 + p92;
                            d92 = d80;
                        }
                    }
                }
            }
            if (rc.onTheMap(l102)) {
                p102 = 10 + rc.senseRubble(l102);
                if (v88 > v101) {
                    if (v101 > v114) {
                        if (v114 > v89) {
                            v102 = v89 + p102;
                            d102 = d89;
                        } else {
                            v102 = v114 + p102;
                            d102 = d114;
                        }
                    } else {
                        if (v101 > v89) {
                            v102 = v89 + p102;
                            d102 = d89;
                        } else {
                            v102 = v101 + p102;
                            d102 = d101;
                        }
                    }
                } else {
                    if (v88 > v114) {
                        if (v114 > v89) {
                            v102 = v89 + p102;
                            d102 = d89;
                        } else {
                            v102 = v114 + p102;
                            d102 = d114;
                        }
                    } else {
                        if (v88 > v89) {
                            v102 = v89 + p102;
                            d102 = d89;
                        } else {
                            v102 = v88 + p102;
                            d102 = d88;
                        }
                    }
                }
            }
            if (rc.onTheMap(l148)) {
                p148 = 10 + rc.senseRubble(l148);
                if (v136 > v135) {
                    if (v135 > v134) {
                        if (v134 > v149) {
                            v148 = v149 + p148;
                            d148 = d149;
                        } else {
                            v148 = v134 + p148;
                            d148 = d134;
                        }
                    } else {
                        if (v135 > v149) {
                            v148 = v149 + p148;
                            d148 = d149;
                        } else {
                            v148 = v135 + p148;
                            d148 = d135;
                        }
                    }
                } else {
                    if (v136 > v134) {
                        if (v134 > v149) {
                            v148 = v149 + p148;
                            d148 = d149;
                        } else {
                            v148 = v134 + p148;
                            d148 = d134;
                        }
                    } else {
                        if (v136 > v149) {
                            v148 = v149 + p148;
                            d148 = d149;
                        } else {
                            v148 = v136 + p148;
                            d148 = d136;
                        }
                    }
                }
            }
            if (rc.onTheMap(l150)) {
                p150 = 10 + rc.senseRubble(l150);
                if (v136 > v137) {
                    if (v137 > v138) {
                        if (v138 > v149) {
                            v150 = v149 + p150;
                            d150 = d149;
                        } else {
                            v150 = v138 + p150;
                            d150 = d138;
                        }
                    } else {
                        if (v137 > v149) {
                            v150 = v149 + p150;
                            d150 = d149;
                        } else {
                            v150 = v137 + p150;
                            d150 = d137;
                        }
                    }
                } else {
                    if (v136 > v138) {
                        if (v138 > v149) {
                            v150 = v149 + p150;
                            d150 = d149;
                        } else {
                            v150 = v138 + p150;
                            d150 = d138;
                        }
                    } else {
                        if (v136 > v149) {
                            v150 = v149 + p150;
                            d150 = d149;
                        } else {
                            v150 = v136 + p150;
                            d150 = d136;
                        }
                    }
                }
            }
            if (rc.onTheMap(l17)) {
                p17 = 10 + rc.senseRubble(l17);
                if (v31 > v30) {
                    if (v30 > v29) {
                        if (v29 > v18) {
                            v17 = v18 + p17;
                            d17 = d18;
                        } else {
                            v17 = v29 + p17;
                            d17 = d29;
                        }
                    } else {
                        if (v30 > v18) {
                            v17 = v18 + p17;
                            d17 = d18;
                        } else {
                            v17 = v30 + p17;
                            d17 = d30;
                        }
                    }
                } else {
                    if (v31 > v29) {
                        if (v29 > v18) {
                            v17 = v18 + p17;
                            d17 = d18;
                        } else {
                            v17 = v29 + p17;
                            d17 = d29;
                        }
                    } else {
                        if (v31 > v18) {
                            v17 = v18 + p17;
                            d17 = d18;
                        } else {
                            v17 = v31 + p17;
                            d17 = d31;
                        }
                    }
                }
            }
            if (rc.onTheMap(l21)) {
                p21 = 10 + rc.senseRubble(l21);
                if (v33 > v34) {
                    if (v34 > v35) {
                        if (v35 > v20) {
                            v21 = v20 + p21;
                            d21 = d20;
                        } else {
                            v21 = v35 + p21;
                            d21 = d35;
                        }
                    } else {
                        if (v34 > v20) {
                            v21 = v20 + p21;
                            d21 = d20;
                        } else {
                            v21 = v34 + p21;
                            d21 = d34;
                        }
                    }
                } else {
                    if (v33 > v35) {
                        if (v35 > v20) {
                            v21 = v20 + p21;
                            d21 = d20;
                        } else {
                            v21 = v35 + p21;
                            d21 = d35;
                        }
                    } else {
                        if (v33 > v20) {
                            v21 = v20 + p21;
                            d21 = d20;
                        } else {
                            v21 = v33 + p21;
                            d21 = d33;
                        }
                    }
                }
            }
            if (rc.onTheMap(l53)) {
                p53 = 10 + rc.senseRubble(l53);
                if (v67 > v54) {
                    if (v54 > v41) {
                        if (v41 > v66) {
                            v53 = v66 + p53;
                            d53 = d66;
                        } else {
                            v53 = v41 + p53;
                            d53 = d41;
                        }
                    } else {
                        if (v54 > v66) {
                            v53 = v66 + p53;
                            d53 = d66;
                        } else {
                            v53 = v54 + p53;
                            d53 = d54;
                        }
                    }
                } else {
                    if (v67 > v41) {
                        if (v41 > v66) {
                            v53 = v66 + p53;
                            d53 = d66;
                        } else {
                            v53 = v41 + p53;
                            d53 = d41;
                        }
                    } else {
                        if (v67 > v66) {
                            v53 = v66 + p53;
                            d53 = d66;
                        } else {
                            v53 = v67 + p53;
                            d53 = d67;
                        }
                    }
                }
            }
            if (rc.onTheMap(l63)) {
                p63 = 10 + rc.senseRubble(l63);
                if (v75 > v62) {
                    if (v62 > v49) {
                        if (v49 > v76) {
                            v63 = v76 + p63;
                            d63 = d76;
                        } else {
                            v63 = v49 + p63;
                            d63 = d49;
                        }
                    } else {
                        if (v62 > v76) {
                            v63 = v76 + p63;
                            d63 = d76;
                        } else {
                            v63 = v62 + p63;
                            d63 = d62;
                        }
                    }
                } else {
                    if (v75 > v49) {
                        if (v49 > v76) {
                            v63 = v76 + p63;
                            d63 = d76;
                        } else {
                            v63 = v49 + p63;
                            d63 = d49;
                        }
                    } else {
                        if (v75 > v76) {
                            v63 = v76 + p63;
                            d63 = d76;
                        } else {
                            v63 = v75 + p63;
                            d63 = d75;
                        }
                    }
                }
            }
            if (rc.onTheMap(l105)) {
                p105 = 10 + rc.senseRubble(l105);
                if (v93 > v106) {
                    if (v106 > v119) {
                        if (v119 > v92) {
                            v105 = v92 + p105;
                            d105 = d92;
                        } else {
                            v105 = v119 + p105;
                            d105 = d119;
                        }
                    } else {
                        if (v106 > v92) {
                            v105 = v92 + p105;
                            d105 = d92;
                        } else {
                            v105 = v106 + p105;
                            d105 = d106;
                        }
                    }
                } else {
                    if (v93 > v119) {
                        if (v119 > v92) {
                            v105 = v92 + p105;
                            d105 = d92;
                        } else {
                            v105 = v119 + p105;
                            d105 = d119;
                        }
                    } else {
                        if (v93 > v92) {
                            v105 = v92 + p105;
                            d105 = d92;
                        } else {
                            v105 = v93 + p105;
                            d105 = d93;
                        }
                    }
                }
            }
            if (rc.onTheMap(l115)) {
                p115 = 10 + rc.senseRubble(l115);
                if (v101 > v114) {
                    if (v114 > v127) {
                        if (v127 > v102) {
                            v115 = v102 + p115;
                            d115 = d102;
                        } else {
                            v115 = v127 + p115;
                            d115 = d127;
                        }
                    } else {
                        if (v114 > v102) {
                            v115 = v102 + p115;
                            d115 = d102;
                        } else {
                            v115 = v114 + p115;
                            d115 = d114;
                        }
                    }
                } else {
                    if (v101 > v127) {
                        if (v127 > v102) {
                            v115 = v102 + p115;
                            d115 = d102;
                        } else {
                            v115 = v127 + p115;
                            d115 = d127;
                        }
                    } else {
                        if (v101 > v102) {
                            v115 = v102 + p115;
                            d115 = d102;
                        } else {
                            v115 = v101 + p115;
                            d115 = d101;
                        }
                    }
                }
            }
            if (rc.onTheMap(l147)) {
                p147 = 10 + rc.senseRubble(l147);
                if (v135 > v134) {
                    if (v134 > v133) {
                        if (v133 > v148) {
                            v147 = v148 + p147;
                            d147 = d148;
                        } else {
                            v147 = v133 + p147;
                            d147 = d133;
                        }
                    } else {
                        if (v134 > v148) {
                            v147 = v148 + p147;
                            d147 = d148;
                        } else {
                            v147 = v134 + p147;
                            d147 = d134;
                        }
                    }
                } else {
                    if (v135 > v133) {
                        if (v133 > v148) {
                            v147 = v148 + p147;
                            d147 = d148;
                        } else {
                            v147 = v133 + p147;
                            d147 = d133;
                        }
                    } else {
                        if (v135 > v148) {
                            v147 = v148 + p147;
                            d147 = d148;
                        } else {
                            v147 = v135 + p147;
                            d147 = d135;
                        }
                    }
                }
            }
            if (rc.onTheMap(l151)) {
                p151 = 10 + rc.senseRubble(l151);
                if (v137 > v138) {
                    if (v138 > v139) {
                        if (v139 > v150) {
                            v151 = v150 + p151;
                            d151 = d150;
                        } else {
                            v151 = v139 + p151;
                            d151 = d139;
                        }
                    } else {
                        if (v138 > v150) {
                            v151 = v150 + p151;
                            d151 = d150;
                        } else {
                            v151 = v138 + p151;
                            d151 = d138;
                        }
                    }
                } else {
                    if (v137 > v139) {
                        if (v139 > v150) {
                            v151 = v150 + p151;
                            d151 = d150;
                        } else {
                            v151 = v139 + p151;
                            d151 = d139;
                        }
                    } else {
                        if (v137 > v150) {
                            v151 = v150 + p151;
                            d151 = d150;
                        } else {
                            v151 = v137 + p151;
                            d151 = d137;
                        }
                    }
                }
            }
            if (rc.onTheMap(l28)) {
                p28 = 10 + rc.senseRubble(l28);
                if (v42 > v29) {
                    if (v29 > v41) {
                        v28 = v41 + p28;
                        d28 = d41;
                    } else {
                        v28 = v29 + p28;
                        d28 = d29;
                    }
                } else {
                    if (v42 > v41) {
                        v28 = v41 + p28;
                        d28 = d41;
                    } else {
                        v28 = v42 + p28;
                        d28 = d42;
                    }
                }
            }
            if (rc.onTheMap(l36)) {
                p36 = 10 + rc.senseRubble(l36);
                if (v48 > v35) {
                    if (v35 > v49) {
                        v36 = v49 + p36;
                        d36 = d49;
                    } else {
                        v36 = v35 + p36;
                        d36 = d35;
                    }
                } else {
                    if (v48 > v49) {
                        v36 = v49 + p36;
                        d36 = d49;
                    } else {
                        v36 = v48 + p36;
                        d36 = d48;
                    }
                }
            }
            if (rc.onTheMap(l132)) {
                p132 = 10 + rc.senseRubble(l132);
                if (v120 > v133) {
                    if (v133 > v119) {
                        v132 = v119 + p132;
                        d132 = d119;
                    } else {
                        v132 = v133 + p132;
                        d132 = d133;
                    }
                } else {
                    if (v120 > v119) {
                        v132 = v119 + p132;
                        d132 = d119;
                    } else {
                        v132 = v120 + p132;
                        d132 = d120;
                    }
                }
            }
            if (rc.onTheMap(l140)) {
                p140 = 10 + rc.senseRubble(l140);
                if (v126 > v127) {
                    if (v127 > v139) {
                        v140 = v139 + p140;
                        d140 = d139;
                    } else {
                        v140 = v127 + p140;
                        d140 = d127;
                    }
                } else {
                    if (v126 > v139) {
                        v140 = v139 + p140;
                        d140 = d139;
                    } else {
                        v140 = v126 + p140;
                        d140 = d126;
                    }
                }
            }
            if (rc.onTheMap(l16)) {
                p16 = 10 + rc.senseRubble(l16);
                if (v30 > v29) {
                    if (v29 > v17) {
                        if (v17 > v28) {
                            v16 = v28 + p16;
                            d16 = d28;
                        } else {
                            v16 = v17 + p16;
                            d16 = d17;
                        }
                    } else {
                        if (v29 > v28) {
                            v16 = v28 + p16;
                            d16 = d28;
                        } else {
                            v16 = v29 + p16;
                            d16 = d29;
                        }
                    }
                } else {
                    if (v30 > v17) {
                        if (v17 > v28) {
                            v16 = v28 + p16;
                            d16 = d28;
                        } else {
                            v16 = v17 + p16;
                            d16 = d17;
                        }
                    } else {
                        if (v30 > v28) {
                            v16 = v28 + p16;
                            d16 = d28;
                        } else {
                            v16 = v30 + p16;
                            d16 = d30;
                        }
                    }
                }
            }
            if (rc.onTheMap(l22)) {
                p22 = 10 + rc.senseRubble(l22);
                if (v34 > v35) {
                    if (v35 > v21) {
                        if (v21 > v36) {
                            v22 = v36 + p22;
                            d22 = d36;
                        } else {
                            v22 = v21 + p22;
                            d22 = d21;
                        }
                    } else {
                        if (v35 > v36) {
                            v22 = v36 + p22;
                            d22 = d36;
                        } else {
                            v22 = v35 + p22;
                            d22 = d35;
                        }
                    }
                } else {
                    if (v34 > v21) {
                        if (v21 > v36) {
                            v22 = v36 + p22;
                            d22 = d36;
                        } else {
                            v22 = v21 + p22;
                            d22 = d21;
                        }
                    } else {
                        if (v34 > v36) {
                            v22 = v36 + p22;
                            d22 = d36;
                        } else {
                            v22 = v34 + p22;
                            d22 = d34;
                        }
                    }
                }
            }
            if (rc.onTheMap(l40)) {
                p40 = 10 + rc.senseRubble(l40);
                if (v54 > v41) {
                    if (v41 > v53) {
                        if (v53 > v28) {
                            v40 = v28 + p40;
                            d40 = d28;
                        } else {
                            v40 = v53 + p40;
                            d40 = d53;
                        }
                    } else {
                        if (v41 > v28) {
                            v40 = v28 + p40;
                            d40 = d28;
                        } else {
                            v40 = v41 + p40;
                            d40 = d41;
                        }
                    }
                } else {
                    if (v54 > v53) {
                        if (v53 > v28) {
                            v40 = v28 + p40;
                            d40 = d28;
                        } else {
                            v40 = v53 + p40;
                            d40 = d53;
                        }
                    } else {
                        if (v54 > v28) {
                            v40 = v28 + p40;
                            d40 = d28;
                        } else {
                            v40 = v54 + p40;
                            d40 = d54;
                        }
                    }
                }
            }
            if (rc.onTheMap(l50)) {
                p50 = 10 + rc.senseRubble(l50);
                if (v62 > v49) {
                    if (v49 > v63) {
                        if (v63 > v36) {
                            v50 = v36 + p50;
                            d50 = d36;
                        } else {
                            v50 = v63 + p50;
                            d50 = d63;
                        }
                    } else {
                        if (v49 > v36) {
                            v50 = v36 + p50;
                            d50 = d36;
                        } else {
                            v50 = v49 + p50;
                            d50 = d49;
                        }
                    }
                } else {
                    if (v62 > v63) {
                        if (v63 > v36) {
                            v50 = v36 + p50;
                            d50 = d36;
                        } else {
                            v50 = v63 + p50;
                            d50 = d63;
                        }
                    } else {
                        if (v62 > v36) {
                            v50 = v36 + p50;
                            d50 = d36;
                        } else {
                            v50 = v62 + p50;
                            d50 = d62;
                        }
                    }
                }
            }
            if (rc.onTheMap(l118)) {
                p118 = 10 + rc.senseRubble(l118);
                if (v106 > v119) {
                    if (v119 > v105) {
                        if (v105 > v132) {
                            v118 = v132 + p118;
                            d118 = d132;
                        } else {
                            v118 = v105 + p118;
                            d118 = d105;
                        }
                    } else {
                        if (v119 > v132) {
                            v118 = v132 + p118;
                            d118 = d132;
                        } else {
                            v118 = v119 + p118;
                            d118 = d119;
                        }
                    }
                } else {
                    if (v106 > v105) {
                        if (v105 > v132) {
                            v118 = v132 + p118;
                            d118 = d132;
                        } else {
                            v118 = v105 + p118;
                            d118 = d105;
                        }
                    } else {
                        if (v106 > v132) {
                            v118 = v132 + p118;
                            d118 = d132;
                        } else {
                            v118 = v106 + p118;
                            d118 = d106;
                        }
                    }
                }
            }
            if (rc.onTheMap(l128)) {
                p128 = 10 + rc.senseRubble(l128);
                if (v114 > v127) {
                    if (v127 > v115) {
                        if (v115 > v140) {
                            v128 = v140 + p128;
                            d128 = d140;
                        } else {
                            v128 = v115 + p128;
                            d128 = d115;
                        }
                    } else {
                        if (v127 > v140) {
                            v128 = v140 + p128;
                            d128 = d140;
                        } else {
                            v128 = v127 + p128;
                            d128 = d127;
                        }
                    }
                } else {
                    if (v114 > v115) {
                        if (v115 > v140) {
                            v128 = v140 + p128;
                            d128 = d140;
                        } else {
                            v128 = v115 + p128;
                            d128 = d115;
                        }
                    } else {
                        if (v114 > v140) {
                            v128 = v140 + p128;
                            d128 = d140;
                        } else {
                            v128 = v114 + p128;
                            d128 = d114;
                        }
                    }
                }
            }
            if (rc.onTheMap(l146)) {
                p146 = 10 + rc.senseRubble(l146);
                if (v134 > v133) {
                    if (v133 > v147) {
                        if (v147 > v132) {
                            v146 = v132 + p146;
                            d146 = d132;
                        } else {
                            v146 = v147 + p146;
                            d146 = d147;
                        }
                    } else {
                        if (v133 > v132) {
                            v146 = v132 + p146;
                            d146 = d132;
                        } else {
                            v146 = v133 + p146;
                            d146 = d133;
                        }
                    }
                } else {
                    if (v134 > v147) {
                        if (v147 > v132) {
                            v146 = v132 + p146;
                            d146 = d132;
                        } else {
                            v146 = v147 + p146;
                            d146 = d147;
                        }
                    } else {
                        if (v134 > v132) {
                            v146 = v132 + p146;
                            d146 = d132;
                        } else {
                            v146 = v134 + p146;
                            d146 = d134;
                        }
                    }
                }
            }
            if (rc.onTheMap(l152)) {
                p152 = 10 + rc.senseRubble(l152);
                if (v138 > v139) {
                    if (v139 > v151) {
                        if (v151 > v140) {
                            v152 = v140 + p152;
                            d152 = d140;
                        } else {
                            v152 = v151 + p152;
                            d152 = d151;
                        }
                    } else {
                        if (v139 > v140) {
                            v152 = v140 + p152;
                            d152 = d140;
                        } else {
                            v152 = v139 + p152;
                            d152 = d139;
                        }
                    }
                } else {
                    if (v138 > v151) {
                        if (v151 > v140) {
                            v152 = v140 + p152;
                            d152 = d140;
                        } else {
                            v152 = v151 + p152;
                            d152 = d151;
                        }
                    } else {
                        if (v138 > v140) {
                            v152 = v140 + p152;
                            d152 = d140;
                        } else {
                            v152 = v138 + p152;
                            d152 = d138;
                        }
                    }
                }
            }

            int dx = target.x - l84.x;
            int dy = target.y - l84.y;
            switch (dx) {
                case -5:
                    switch (dy) {
                        case -3:
                            return d16;
                        case -2:
                            return d17;
                        case -1:
                            return d18;
                        case 0:
                            return d19;
                        case 1:
                            return d20;
                        case 2:
                            return d21;
                        case 3:
                            return d22;
                    }
                    break;
                case -4:
                    switch (dy) {
                        case -4:
                            return d28;
                        case -3:
                            return d29;
                        case -2:
                            return d30;
                        case -1:
                            return d31;
                        case 0:
                            return d32;
                        case 1:
                            return d33;
                        case 2:
                            return d34;
                        case 3:
                            return d35;
                        case 4:
                            return d36;
                    }
                    break;
                case -3:
                    switch (dy) {
                        case -5:
                            return d40;
                        case -4:
                            return d41;
                        case -3:
                            return d42;
                        case -2:
                            return d43;
                        case -1:
                            return d44;
                        case 0:
                            return d45;
                        case 1:
                            return d46;
                        case 2:
                            return d47;
                        case 3:
                            return d48;
                        case 4:
                            return d49;
                        case 5:
                            return d50;
                    }
                    break;
                case -2:
                    switch (dy) {
                        case -5:
                            return d53;
                        case -4:
                            return d54;
                        case -3:
                            return d55;
                        case -2:
                            return d56;
                        case -1:
                            return d57;
                        case 0:
                            return d58;
                        case 1:
                            return d59;
                        case 2:
                            return d60;
                        case 3:
                            return d61;
                        case 4:
                            return d62;
                        case 5:
                            return d63;
                    }
                    break;
                case -1:
                    switch (dy) {
                        case -5:
                            return d66;
                        case -4:
                            return d67;
                        case -3:
                            return d68;
                        case -2:
                            return d69;
                        case -1:
                            return d70;
                        case 0:
                            return d71;
                        case 1:
                            return d72;
                        case 2:
                            return d73;
                        case 3:
                            return d74;
                        case 4:
                            return d75;
                        case 5:
                            return d76;
                    }
                    break;
                case 0:
                    switch (dy) {
                        case -5:
                            return d79;
                        case -4:
                            return d80;
                        case -3:
                            return d81;
                        case -2:
                            return d82;
                        case -1:
                            return d83;
                        case 0:
                            return d84;
                        case 1:
                            return d85;
                        case 2:
                            return d86;
                        case 3:
                            return d87;
                        case 4:
                            return d88;
                        case 5:
                            return d89;
                    }
                    break;
                case 1:
                    switch (dy) {
                        case -5:
                            return d92;
                        case -4:
                            return d93;
                        case -3:
                            return d94;
                        case -2:
                            return d95;
                        case -1:
                            return d96;
                        case 0:
                            return d97;
                        case 1:
                            return d98;
                        case 2:
                            return d99;
                        case 3:
                            return d100;
                        case 4:
                            return d101;
                        case 5:
                            return d102;
                    }
                    break;
                case 2:
                    switch (dy) {
                        case -5:
                            return d105;
                        case -4:
                            return d106;
                        case -3:
                            return d107;
                        case -2:
                            return d108;
                        case -1:
                            return d109;
                        case 0:
                            return d110;
                        case 1:
                            return d111;
                        case 2:
                            return d112;
                        case 3:
                            return d113;
                        case 4:
                            return d114;
                        case 5:
                            return d115;
                    }
                    break;
                case 3:
                    switch (dy) {
                        case -5:
                            return d118;
                        case -4:
                            return d119;
                        case -3:
                            return d120;
                        case -2:
                            return d121;
                        case -1:
                            return d122;
                        case 0:
                            return d123;
                        case 1:
                            return d124;
                        case 2:
                            return d125;
                        case 3:
                            return d126;
                        case 4:
                            return d127;
                        case 5:
                            return d128;
                    }
                    break;
                case 4:
                    switch (dy) {
                        case -4:
                            return d132;
                        case -3:
                            return d133;
                        case -2:
                            return d134;
                        case -1:
                            return d135;
                        case 0:
                            return d136;
                        case 1:
                            return d137;
                        case 2:
                            return d138;
                        case 3:
                            return d139;
                        case 4:
                            return d140;
                    }
                    break;
                case 5:
                    switch (dy) {
                        case -3:
                            return d146;
                        case -2:
                            return d147;
                        case -1:
                            return d148;
                        case 0:
                            return d149;
                        case 1:
                            return d150;
                        case 2:
                            return d151;
                        case 3:
                            return d152;
                    }
                    break;
            }

            Direction ans = null;
            double bestEstimation = 0;
            double initialDist = Math.sqrt(l84.distanceSquaredTo(target));

            double dist16 = (initialDist - Math.sqrt(l16.distanceSquaredTo(target))) / v16;
            if (dist16 > bestEstimation) {
                bestEstimation = dist16;
                ans = d16;
            }
            double dist17 = (initialDist - Math.sqrt(l17.distanceSquaredTo(target))) / v17;
            if (dist17 > bestEstimation) {
                bestEstimation = dist17;
                ans = d17;
            }
            double dist18 = (initialDist - Math.sqrt(l18.distanceSquaredTo(target))) / v18;
            if (dist18 > bestEstimation) {
                bestEstimation = dist18;
                ans = d18;
            }
            double dist19 = (initialDist - Math.sqrt(l19.distanceSquaredTo(target))) / v19;
            if (dist19 > bestEstimation) {
                bestEstimation = dist19;
                ans = d19;
            }
            double dist20 = (initialDist - Math.sqrt(l20.distanceSquaredTo(target))) / v20;
            if (dist20 > bestEstimation) {
                bestEstimation = dist20;
                ans = d20;
            }
            double dist21 = (initialDist - Math.sqrt(l21.distanceSquaredTo(target))) / v21;
            if (dist21 > bestEstimation) {
                bestEstimation = dist21;
                ans = d21;
            }
            double dist22 = (initialDist - Math.sqrt(l22.distanceSquaredTo(target))) / v22;
            if (dist22 > bestEstimation) {
                bestEstimation = dist22;
                ans = d22;
            }
            double dist28 = (initialDist - Math.sqrt(l28.distanceSquaredTo(target))) / v28;
            if (dist28 > bestEstimation) {
                bestEstimation = dist28;
                ans = d28;
            }
            double dist29 = (initialDist - Math.sqrt(l29.distanceSquaredTo(target))) / v29;
            if (dist29 > bestEstimation) {
                bestEstimation = dist29;
                ans = d29;
            }
            double dist35 = (initialDist - Math.sqrt(l35.distanceSquaredTo(target))) / v35;
            if (dist35 > bestEstimation) {
                bestEstimation = dist35;
                ans = d35;
            }
            double dist36 = (initialDist - Math.sqrt(l36.distanceSquaredTo(target))) / v36;
            if (dist36 > bestEstimation) {
                bestEstimation = dist36;
                ans = d36;
            }
            double dist40 = (initialDist - Math.sqrt(l40.distanceSquaredTo(target))) / v40;
            if (dist40 > bestEstimation) {
                bestEstimation = dist40;
                ans = d40;
            }
            double dist41 = (initialDist - Math.sqrt(l41.distanceSquaredTo(target))) / v41;
            if (dist41 > bestEstimation) {
                bestEstimation = dist41;
                ans = d41;
            }
            double dist49 = (initialDist - Math.sqrt(l49.distanceSquaredTo(target))) / v49;
            if (dist49 > bestEstimation) {
                bestEstimation = dist49;
                ans = d49;
            }
            double dist50 = (initialDist - Math.sqrt(l50.distanceSquaredTo(target))) / v50;
            if (dist50 > bestEstimation) {
                bestEstimation = dist50;
                ans = d50;
            }
            double dist53 = (initialDist - Math.sqrt(l53.distanceSquaredTo(target))) / v53;
            if (dist53 > bestEstimation) {
                bestEstimation = dist53;
                ans = d53;
            }
            double dist63 = (initialDist - Math.sqrt(l63.distanceSquaredTo(target))) / v63;
            if (dist63 > bestEstimation) {
                bestEstimation = dist63;
                ans = d63;
            }
            double dist66 = (initialDist - Math.sqrt(l66.distanceSquaredTo(target))) / v66;
            if (dist66 > bestEstimation) {
                bestEstimation = dist66;
                ans = d66;
            }
            double dist76 = (initialDist - Math.sqrt(l76.distanceSquaredTo(target))) / v76;
            if (dist76 > bestEstimation) {
                bestEstimation = dist76;
                ans = d76;
            }
            double dist79 = (initialDist - Math.sqrt(l79.distanceSquaredTo(target))) / v79;
            if (dist79 > bestEstimation) {
                bestEstimation = dist79;
                ans = d79;
            }
            double dist89 = (initialDist - Math.sqrt(l89.distanceSquaredTo(target))) / v89;
            if (dist89 > bestEstimation) {
                bestEstimation = dist89;
                ans = d89;
            }
            double dist92 = (initialDist - Math.sqrt(l92.distanceSquaredTo(target))) / v92;
            if (dist92 > bestEstimation) {
                bestEstimation = dist92;
                ans = d92;
            }
            double dist102 = (initialDist - Math.sqrt(l102.distanceSquaredTo(target))) / v102;
            if (dist102 > bestEstimation) {
                bestEstimation = dist102;
                ans = d102;
            }
            double dist105 = (initialDist - Math.sqrt(l105.distanceSquaredTo(target))) / v105;
            if (dist105 > bestEstimation) {
                bestEstimation = dist105;
                ans = d105;
            }
            double dist115 = (initialDist - Math.sqrt(l115.distanceSquaredTo(target))) / v115;
            if (dist115 > bestEstimation) {
                bestEstimation = dist115;
                ans = d115;
            }
            double dist118 = (initialDist - Math.sqrt(l118.distanceSquaredTo(target))) / v118;
            if (dist118 > bestEstimation) {
                bestEstimation = dist118;
                ans = d118;
            }
            double dist119 = (initialDist - Math.sqrt(l119.distanceSquaredTo(target))) / v119;
            if (dist119 > bestEstimation) {
                bestEstimation = dist119;
                ans = d119;
            }
            double dist127 = (initialDist - Math.sqrt(l127.distanceSquaredTo(target))) / v127;
            if (dist127 > bestEstimation) {
                bestEstimation = dist127;
                ans = d127;
            }
            double dist128 = (initialDist - Math.sqrt(l128.distanceSquaredTo(target))) / v128;
            if (dist128 > bestEstimation) {
                bestEstimation = dist128;
                ans = d128;
            }
            double dist132 = (initialDist - Math.sqrt(l132.distanceSquaredTo(target))) / v132;
            if (dist132 > bestEstimation) {
                bestEstimation = dist132;
                ans = d132;
            }
            double dist133 = (initialDist - Math.sqrt(l133.distanceSquaredTo(target))) / v133;
            if (dist133 > bestEstimation) {
                bestEstimation = dist133;
                ans = d133;
            }
            double dist139 = (initialDist - Math.sqrt(l139.distanceSquaredTo(target))) / v139;
            if (dist139 > bestEstimation) {
                bestEstimation = dist139;
                ans = d139;
            }
            double dist140 = (initialDist - Math.sqrt(l140.distanceSquaredTo(target))) / v140;
            if (dist140 > bestEstimation) {
                bestEstimation = dist140;
                ans = d140;
            }
            double dist146 = (initialDist - Math.sqrt(l146.distanceSquaredTo(target))) / v146;
            if (dist146 > bestEstimation) {
                bestEstimation = dist146;
                ans = d146;
            }
            double dist147 = (initialDist - Math.sqrt(l147.distanceSquaredTo(target))) / v147;
            if (dist147 > bestEstimation) {
                bestEstimation = dist147;
                ans = d147;
            }
            double dist148 = (initialDist - Math.sqrt(l148.distanceSquaredTo(target))) / v148;
            if (dist148 > bestEstimation) {
                bestEstimation = dist148;
                ans = d148;
            }
            double dist149 = (initialDist - Math.sqrt(l149.distanceSquaredTo(target))) / v149;
            if (dist149 > bestEstimation) {
                bestEstimation = dist149;
                ans = d149;
            }
            double dist150 = (initialDist - Math.sqrt(l150.distanceSquaredTo(target))) / v150;
            if (dist150 > bestEstimation) {
                bestEstimation = dist150;
                ans = d150;
            }
            double dist151 = (initialDist - Math.sqrt(l151.distanceSquaredTo(target))) / v151;
            if (dist151 > bestEstimation) {
                bestEstimation = dist151;
                ans = d151;
            }
            double dist152 = (initialDist - Math.sqrt(l152.distanceSquaredTo(target))) / v152;
            if (dist152 > bestEstimation) {
                ans = d152;
            }
            return ans;
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }





}
