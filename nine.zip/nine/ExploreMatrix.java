package nine;

public class ExploreMatrix {

    int[][] expl;

    ExploreMatrix(int dim){

    }

}
