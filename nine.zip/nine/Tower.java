package nine;

import battlecode.common.RobotController;

public class Tower extends Robot {

    Tower(RobotController rc){
        super(rc);
    }

    void play(){

    }

}
