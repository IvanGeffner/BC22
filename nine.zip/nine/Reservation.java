package nine;

import battlecode.common.RobotType;

public class Reservation {

    boolean first = true;
    int savedLead = 0;
    RobotType t = null;

    Reservation(){

    }

}
