package thirdbot;

public class Constants {

    final static int MIN_LEAD_RELEVANT = 10;

}
